// server.ts
import express, { Request, Response, NextFunction } from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

// Define standard Delhi geographical locations and nodes in the multimodal system
interface GpsNode {
  lat: number;
  lng: number;
  is_metro?: boolean;
  is_bus?: boolean;
  is_train?: boolean;
  is_feeder?: boolean;
}

const DELHI_NODES: Record<string, GpsNode> = {
  "Rajiv Chowk": { lat: 28.6304, lng: 77.2177, is_metro: true },
  "Kashmere Gate": { lat: 28.6675, lng: 77.2281, is_metro: true },
  "GTB Nagar": { lat: 28.6922, lng: 77.2078, is_metro: true, is_bus: true },
  "HUDA City Centre": { lat: 28.4593, lng: 77.0724, is_metro: true },
  "Noida Sector 62": { lat: 28.6219, lng: 77.3639, is_metro: true },
  "Hazrat Nizamuddin": { lat: 28.5888, lng: 77.2536, is_train: true, is_bus: true },
  "New Delhi Station": { lat: 28.6418, lng: 77.2219, is_metro: true, is_train: true },
  "Vasant Kunj Sector C": { lat: 28.5298, lng: 77.1518, is_bus: true },
  "Connaught Place Block A": { lat: 28.6322, lng: 77.2195, is_feeder: true },
  "Delhi University Gate": { lat: 28.6895, lng: 77.2115, is_feeder: true },
  "Anand Vihar": { lat: 28.6468, lng: 77.3160, is_metro: true, is_train: true, is_bus: true },
};

interface TransitEdge {
  u: string;
  v: string;
  mode: string;
  line?: string;
  route?: string;
  dist_km: number;
  time_min: number;
  fare: number;
}

const TRANSIT_EDGES: TransitEdge[] = [
  // 1. Delhi Metro Connections (0.05g/km CO2 emissions)
  { u: "Rajiv Chowk", v: "Kashmere Gate", mode: "METRO", line: "Yellow Line", dist_km: 6.8, time_min: 12, fare: 30.0 },
  { u: "Rajiv Chowk", v: "HUDA City Centre", mode: "METRO", line: "Yellow Line", dist_km: 28.5, time_min: 50, fare: 60.0 },
  { u: "Kashmere Gate", v: "GTB Nagar", mode: "METRO", line: "Yellow Line", dist_km: 4.5, time_min: 8, fare: 20.0 },
  { u: "Rajiv Chowk", v: "Noida Sector 62", mode: "METRO", line: "Blue Line", dist_km: 18.2, time_min: 35, fare: 50.0 },
  { u: "Rajiv Chowk", v: "New Delhi Station", mode: "METRO", line: "Yellow Line", dist_km: 2.1, time_min: 4, fare: 15.0 },
  { u: "New Delhi Station", v: "Kashmere Gate", mode: "METRO", line: "Yellow Line", dist_km: 4.7, time_min: 8, fare: 20.0 },
  { u: "New Delhi Station", v: "Anand Vihar", mode: "METRO", line: "Blue Line", dist_km: 11.2, time_min: 22, fare: 40.0 },

  // 2. DTC Bus Connections (Green CNG buses)
  { u: "GTB Nagar", v: "Kashmere Gate", mode: "BUS", route: "502", dist_km: 5.2, time_min: 18, fare: 15.0 },
  { u: "Kashmere Gate", v: "Hazrat Nizamuddin", mode: "BUS", route: "419", dist_km: 11.8, time_min: 40, fare: 25.0 },
  { u: "Rajiv Chowk", v: "Hazrat Nizamuddin", mode: "BUS", route: "312", dist_km: 8.5, time_min: 30, fare: 20.0 },
  { u: "Vasant Kunj Sector C", v: "Rajiv Chowk", mode: "BUS", route: "604", dist_km: 16.5, time_min: 55, fare: 25.0 },
  { u: "Vasant Kunj Sector C", v: "Hazrat Nizamuddin", mode: "BUS", route: "727", dist_km: 14.1, time_min: 48, fare: 25.0 },
  { u: "Kashmere Gate", v: "Anand Vihar", mode: "BUS", route: "821", dist_km: 12.5, time_min: 45, fare: 25.0 },

  // 3. Local Train EMU Connections
  { u: "Hazrat Nizamuddin", v: "New Delhi Station", mode: "TRAIN", route: "EMU-S1", dist_km: 7.5, time_min: 15, fare: 10.0 },
  { u: "New Delhi Station", v: "Anand Vihar", mode: "TRAIN", route: "EMU-S2", dist_km: 10.5, time_min: 18, fare: 10.0 },

  // 4. E-Rickshaw Connections
  { u: "Rajiv Chowk", v: "Connaught Place Block A", mode: "RICKSHAW", dist_km: 0.8, time_min: 5, fare: 15.0 },
  { u: "GTB Nagar", v: "Delhi University Gate", mode: "RICKSHAW", dist_km: 1.2, time_min: 8, fare: 20.0 },

  // 5. Pedestrian Walking Links
  { u: "Rajiv Chowk", v: "Connaught Place Block A", mode: "WALK", dist_km: 0.6, time_min: 8, fare: 0.0 },
  { u: "GTB Nagar", v: "Delhi University Gate", mode: "WALK", dist_km: 1.1, time_min: 15, fare: 0.0 },
  { u: "New Delhi Station", v: "Connaught Place Block A", mode: "WALK", dist_km: 1.5, time_min: 20, fare: 0.0 },
];

// Bidirectional mapping expansion
const BIDI_EDGES: TransitEdge[] = [];
TRANSIT_EDGES.forEach((edge) => {
  BIDI_EDGES.push(edge);
  BIDI_EDGES.push({
    ...edge,
    u: edge.v,
    v: edge.u,
  });
});

const CARBON_EMISSIONS_g: Record<string, number> = {
  METRO: 4.5,
  BUS: 12.0,
  TRAIN: 18.0,
  RICKSHAW: 2.0,
  WALK: 0.0,
};

// State-preserving memory stores simulating persistent Neon Postgres
const usersDb = [
  {
    id: "9999-9999-9999-9999",
    email: "recruiter@onetransit.in",
    full_name: "Elite Recruiter",
    role: "Admin",
    status: "active",
    is_verified: true,
    created_at: new Date().toISOString(),
    profile: {
      phone_number: "+91 98765 43210",
      preferred_language: "en",
      home_latitude: "28.6304",
      home_longitude: "77.2177",
      work_latitude: "28.6922",
      work_longitude: "77.2078",
    },
    wallet: {
      id: "wallet-rec-id",
      balance: 1000.0,
      status: "active",
      updated_at: new Date().toISOString(),
    },
    transactions: [
      {
        id: "tx-init-id",
        amount: 1000.0,
        transaction_type: "credit",
        description: "Welcome Recruiter Bonus Staging Credit",
        reference_id: "TXN-WELCOME1K",
        status: "completed",
        created_at: new Date().toISOString(),
      },
    ],
    passes: [
      {
        id: "pass-init-id",
        pass_type: "Delhi Metro 30-Day Pass",
        transport_mode: "METRO",
        price: 500.0,
        starts_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        is_active: true,
      },
    ],
    trips: [
      {
        id: "trip-init-id",
        source_address: "Rajiv Chowk",
        destination_address: "GTB Nagar",
        total_fare: 50.0,
        total_distance_km: 11.3,
        total_duration_minutes: 20,
        co2_saved_g: 1530.0,
        start_time: new Date(Date.now() - 2 * 24 *  60 * 60 * 1000).toISOString(),
        end_time: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        legs: [
          {
            id: "leg-1",
            transport_code: "METRO",
            source_name: "Rajiv Chowk",
            destination_name: "Kashmere Gate",
            fare: 30.0,
            distance_km: 6.8,
            duration_minutes: 12,
            sequence_order: 1,
          },
          {
            id: "leg-2",
            transport_code: "BUS",
            source_name: "Kashmere Gate",
            destination_name: "GTB Nagar",
            fare: 20.0,
            distance_km: 4.5,
            duration_minutes: 8,
            sequence_order: 2,
          }
        ],
      },
    ],
  },
];

async function startServer() {
  const app = express();
  app.use(express.json());

  // CORS Headers definition
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
    if (req.method === "OPTIONS") {
      res.sendStatus(200);
      return;
    }
    next();
  });

  // Authentication Helper Middleware
  const authenticateToken = (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers["authorization"];
    const token = typeof authHeader === "string" ? authHeader.split(" ")[1] : null;

    if (!token) {
      res.status(401).json({ detail: "Authorization Token is missing." });
      return;
    }

    // Direct token identification representing active database indexes in the preview
    const payloadUserId = token.replace("MOCK-JWT-USER-", "");
    const user = usersDb.find((u) => u.id === payloadUserId || u.email === token);

    if (!user) {
      res.status(401).json({ detail: "User session expired or unauthorized." });
      return;
    }

    (req as any).user = user;
    next();
  };

  // ===================================================================
  // 1. AUTHENTICATION MODULE ENDPOINTS
  // ===================================================================

  app.post("/api/v1/auth/signup", (req, res) => {
    const { email, password, full_name } = req.body;

    const existing = usersDb.find((u) => u.email === email);
    if (existing) {
      res.status(400).json({ detail: "Email address already registered with OneTransit" });
      return;
    }

    const newId = `usr-${Math.random().toString(36).substr(2, 9)}`;
    const newUser = {
      id: newId,
      email,
      full_name,
      role: "User",
      status: "active",
      is_verified: true,
      created_at: new Date().toISOString(),
      profile: {
        phone_number: "",
        preferred_language: "en",
        home_latitude: "28.6304",
        home_longitude: "77.2177",
        work_latitude: "28.6922",
        work_longitude: "77.2078",
      },
      wallet: {
        id: `wallet-${newId}`,
        balance: 350.0, // generous initial recruiter free balance seeding
        status: "active",
        updated_at: new Date().toISOString(),
      },
      transactions: [
        {
          id: `tx-${newId}`,
          amount: 350.0,
          transaction_type: "credit",
          description: "Sign-On Welcome Pocket Recharge",
          reference_id: `TXN-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
          status: "completed",
          created_at: new Date().toISOString(),
        },
      ],
      passes: [] as any[],
      trips: [] as any[],
    };

    usersDb.push(newUser);
    res.status(201).json(newUser);
  });

  app.post("/api/v1/auth/login", (req, res) => {
    const { email, password } = req.body;

    const user = usersDb.find((u) => u.email === email);
    if (!user) {
      res.status(401).json({ detail: "Authentication combination not found" });
      return;
    }

    // Direct mock token issue linking user ID natively
    res.json({
      access_token: `MOCK-JWT-USER-${user.id}`,
      refresh_token: `MOCK-REFRESH-USER-${user.id}`,
      token_type: "bearer",
    });
  });

  app.get("/api/v1/auth/profile", authenticateToken, (req, res) => {
    res.json((req as any).user);
  });

  app.put("/api/v1/auth/profile", authenticateToken, (req, res) => {
    const user = (req as any).user;
    const { phone_number, preferred_language, home_latitude, home_longitude, work_latitude, work_longitude } = req.body;

    user.profile = {
      ...user.profile,
      phone_number: phone_number ?? user.profile.phone_number,
      preferred_language: preferred_language ?? user.profile.preferred_language,
      home_latitude: home_latitude ?? user.profile.home_latitude,
      home_longitude: home_longitude ?? user.profile.home_longitude,
      work_latitude: work_latitude ?? user.profile.work_latitude,
      work_longitude: work_longitude ?? user.profile.work_longitude,
    };

    res.json(user);
  });

  // ===================================================================
  // 2. SMART WALLET MODULE ENDPOINTS
  // ===================================================================

  app.get("/api/v1/wallet", authenticateToken, (req, res) => {
    const user = (req as any).user;
    res.json({
      wallet: user.wallet,
      transactions: user.transactions,
      active_passes: user.passes.filter((p: any) => new Date(p.expires_at) > new Date()),
    });
  });

  app.post("/api/v1/wallet/recharge", authenticateToken, (req, res) => {
    const user = (req as any).user;
    const { amount, payment_method } = req.body;

    if (amount <= 0 || amount > 5000) {
      res.status(400).json({ detail: "Recharge amount should be between ₹1 and ₹5000." });
      return;
    }

    user.wallet.balance += amount;
    user.wallet.updated_at = new Date().toISOString();

    const txn = {
      id: `tx-${Math.random().toString(36).substr(2, 9)}`,
      amount,
      transaction_type: "credit",
      description: `Recharge via ${payment_method || "UPI"}`,
      reference_id: `TXN-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      status: "completed",
      created_at: new Date().toISOString(),
    };

    user.transactions.unshift(txn);
    res.json(txn);
  });

  app.post("/api/v1/wallet/purchase_pass", authenticateToken, (req, res) => {
    const user = (req as any).user;
    const { pass_type, transport_mode, price } = req.body;

    if (user.wallet.balance < price) {
      res.status(400).json({ detail: "Insufficient balance to purchase this subscription pass" });
      return;
    }

    user.wallet.balance -= price;
    user.wallet.updated_at = new Date().toISOString();

    const txn = {
      id: `tx-pass-${Math.random().toString(36).substr(2, 9)}`,
      amount: price,
      transaction_type: "debit",
      description: `Purchased subscription: ${pass_type}`,
      reference_id: `TXN-PASS-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      status: "completed",
      created_at: new Date().toISOString(),
    };
    user.transactions.unshift(txn);

    const newPass = {
      id: `pass-${Math.random().toString(36).substr(2, 9)}`,
      pass_type,
      transport_mode,
      price,
      starts_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      is_active: true,
    };
    user.passes.unshift(newPass);

    res.json(newPass);
  });

  // ===================================================================
  // 3. DIJKSTRA ROUTE PLANNER ENDPOINTS
  // ===================================================================

  app.get("/api/v1/router/landmarks", (req, res) => {
    res.json(DELHI_NODES);
  });

  app.post("/api/v1/router/search", (req, res) => {
    const { source, destination, priority } = req.body;

    if (!DELHI_NODES[source] || !DELHI_NODES[destination]) {
      res.status(400).json({ detail: "Selected landmarks do not belong to active networks." });
      return;
    }

    if (source === destination) {
      res.status(400).json({ detail: "Destination landmark cannot match origin." });
      return;
    }

    // Execute TS Dijkstra Implementation
    const solveDijkstraPath = (src: string, dst: string): TransitEdge[] | null => {
      interface HeapNode {
        cost: number;
        node: string;
        lastMode: string;
        path: TransitEdge[];
      }

      const pq: HeapNode[] = [{ cost: 0, node: src, lastMode: "START", path: [] }];
      const visited = new Map<string, number>();

      while (pq.length > 0) {
        pq.sort((a, b) => a.cost - b.cost);
        const { cost, node, lastMode, path } = pq.shift()!;

        if (node === dst) {
          return path;
        }

        const stateKey = `${node}-${lastMode}`;
        if (visited.has(stateKey) && visited.get(stateKey)! <= cost) {
          continue;
        }
        visited.set(stateKey, cost);

        const edges = BIDI_EDGES.filter((e) => e.u === node);
        for (const edge of edges) {
          let stepCost = cost;

          // Multi-Criteria Priority adjustment
          if (priority === "cheapest") {
            stepCost += edge.fare * 1.0 + edge.time_min * 0.1;
          } else if (priority === "lowest_walking") {
            stepCost += (edge.mode === "WALK" ? 1.0 : 0.1) * edge.time_min + edge.time_min * 0.3;
          } else if (priority === "minimum_interchanges") {
            const interchangeCost = (lastMode !== "START" && edge.mode !== lastMode && lastMode !== "WALK") ? 30.0 : 0.0;
            stepCost += interchangeCost + edge.time_min * 0.2;
          } else {
            // fastest Standard prioritizers
            stepCost += edge.time_min;
          }

          pq.push({
            cost: stepCost,
            node: edge.v,
            lastMode: edge.mode,
            path: [...path, edge],
          });
        }
      }
      return null;
    };

    let resultPath = solveDijkstraPath(source, destination);

    const legs = (resultPath || []).map((e) => ({
      transport_mode: e.mode,
      source_name: e.u,
      destination_name: e.v,
      distance_km: e.dist_km,
      duration_minutes: e.time_min,
      fare: e.fare,
      line_name: e.line || null,
      route_code: e.route || null,
    }));

    if (legs.length === 0) {
      // Build Fallback Walking direction
      res.json({
        route_id: `R-FALL-${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
        legs: [
          {
            transport_mode: "WALK",
            source_name: source,
            destination_name: `${source} Catchment`,
            distance_km: 1.0,
            duration_minutes: 15,
            fare: 0.0,
          },
          {
            transport_mode: "RICKSHAW",
            source_name: `${source} Catchment`,
            destination_name: destination,
            distance_km: 2.2,
            duration_minutes: 10,
            fare: 25.0,
          }
        ],
        total_fare: 25.0,
        total_distance_km: 3.2,
        total_duration_minutes: 25,
        carbon_saved_g: 450.0,
        number_of_interchanges: 1,
      });
      return;
    }

    const total_fare = legs.reduce((sum, current) => sum + current.fare, 0);
    const total_dist = legs.reduce((sum, current) => sum + current.distance_km, 0);
    const total_time = legs.reduce((sum, current) => sum + current.duration_minutes, 0);
    const carbon_saved = total_dist * 135.0; // Round comparative baseline and g saved

    // Count line switches code
    let interchanges = 0;
    let pMode = "";
    legs.forEach((leg) => {
      if (pMode && leg.transport_mode !== pMode && pMode !== "WALK") {
        interchanges += 1;
      }
      pMode = leg.transport_mode;
    });

    res.json({
      route_id: `R-${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
      legs,
      total_fare,
      total_distance_km: parseFloat(total_dist.toFixed(1)),
      total_duration_minutes: total_time,
      carbon_saved_g: Math.round(carbon_saved),
      number_of_interchanges: interchanges,
    });
  });

  // ===================================================================
  // 4. TRAVEL HISTORY & ANALYTICS ENDPOINTS
  // ===================================================================

  app.get("/api/v1/history", authenticateToken, (req, res) => {
    res.json((req as any).user.trips);
  });

  app.post("/api/v1/history/log_trip", authenticateToken, (req, res) => {
    const user = (req as any).user;
    const { source_address, destination_address, total_fare, total_distance_km, total_duration_minutes, co2_saved_g, legs } = req.body;

    const newTrip = {
      id: `trip-${Math.random().toString(36).substr(2, 9)}`,
      source_address,
      destination_address,
      total_fare,
      total_distance_km,
      total_duration_minutes,
      co2_saved_g,
      start_time: new Date().toISOString(),
      end_time: new Date(Date.now() + total_duration_minutes * 60 * 1000).toISOString(),
      legs: legs.map((leg: any, idx: number) => ({
        ...leg,
        id: `leg-${idx}-${Math.random().toString(36).substr(2, 5)}`,
        sequence_order: idx + 1,
      })),
    };

    user.trips.unshift(newTrip);

    // Also debit fare cost from balance if wallet is used!
    if (user.wallet.balance >= total_fare) {
      user.wallet.balance -= total_fare;
      user.wallet.updated_at = new Date().toISOString();
      const debitTx = {
        id: `tx-ticket-${Math.random().toString(36).substr(2, 9)}`,
        amount: total_fare,
        transaction_type: "debit",
        description: `Travel Ticket: ${source_address} to ${destination_address}`,
        reference_id: `TXN-TCK-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
        status: "completed",
        created_at: new Date().toISOString(),
      };
      user.transactions.unshift(debitTx);
    }

    res.json(newTrip);
  });

  app.get("/api/v1/history/analytics", authenticateToken, (req, res) => {
    const user = (req as any).user;
    const trips = user.trips;

    const totalSpent = trips.reduce((sum: number, current: any) => sum + current.total_fare, 0);
    const co2Saved = trips.reduce((sum: number, current: any) => sum + current.co2_saved_g, 0);
    const avgDist = trips.length > 0 ? trips.reduce((sum: number, current: any) => sum + current.total_distance_km, 0) / trips.length : 0.0;

    // Dist list
    const modeCounts: Record<string, number> = { METRO: 0, BUS: 0, RICKSHAW: 0, WALK: 0 };
    trips.forEach((trip: any) => {
      trip.legs.forEach((leg: any) => {
        if (modeCounts[leg.transport_code] !== undefined) {
          modeCounts[leg.transport_code] += 1;
        } else {
          modeCounts[leg.transport_code] = 1;
        }
      });
    });

    const mostUsedMode = Object.keys(modeCounts).reduce((a, b) => modeCounts[a] > modeCounts[b] ? a : b, "METRO");

    const distributions = Object.keys(modeCounts).map((key) => ({
      mode: key,
      trips: modeCounts[key],
    }));

    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const currentM = new Date().getMonth();
    const listHistory = [];

    for (let i = 5; i >= 0; i--) {
      const idx = (currentM - i + 12) % 12;
      listHistory.push({
        month: months[idx],
        amount: trips.length > 0 ? (totalSpent * (0.1 + (i % 3) * 0.15)) : 50.0 + (i * 20),
      });
    }

    res.json({
      total_spending_inr: parseFloat(totalSpent.toFixed(2)),
      total_trips_conducted: trips.length,
      average_distance_km: parseFloat(avgDist.toFixed(1)),
      most_used_mode: mostUsedMode,
      carbon_emissions_saved_g: co2Saved,
      peak_travel_time_hour: "08:45 AM - 10:15 AM",
      spending_history: listHistory,
      mode_distribution: distributions,
    });
  });

  // ===================================================================
  // 5. ADMIN CONTROL PRIVILEGES ENDPOINTS
  // ===================================================================

  app.get("/api/v1/admin/users", authenticateToken, (req, res) => {
    if ((req as any).user.role !== "Admin") {
      res.status(403).json({ detail: "Forbidden." });
      return;
    }
    // Return brief safe summary representation of registered accounts
    const formatted = usersDb.map((u) => ({
      id: u.id,
      email: u.email,
      full_name: u.full_name,
      role: u.role,
      status: u.status,
      is_verified: u.is_verified,
      created_at: u.created_at,
    }));
    res.json(formatted);
  });

  app.get("/api/v1/admin/transactions", authenticateToken, (req, res) => {
    if ((req as any).user.role !== "Admin") {
      res.status(403).json({ detail: "Forbidden." });
      return;
    }
    const list: any[] = [];
    usersDb.forEach((u) => {
      u.transactions.forEach((tx) => {
        list.push({
          ...tx,
          user_email: u.email,
          user_name: u.full_name,
        });
      });
    });
    res.json(list);
  });

  // Health and root status
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", mode: "full-stack-unified-preview-active" });
  });

  // ===================================================================
  // 6. VITE ENGINE OR STATIC ASSET BUNDLERS
  // ===================================================================

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Delhi OneTransit unified platform running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error("Vite server loader failed to initialize context on boot:", err);
});
