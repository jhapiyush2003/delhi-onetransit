// src/views/Profile.tsx
import React, { useState } from "react";
import { User as UserIcon, Phone, Globe, Home, Briefcase, CheckCircle2, ShieldCheck } from "lucide-react";
import { User, UserProfile } from "../types";

interface ProfileProps {
  user: User;
  onUpdateProfile: (profile: UserProfile) => Promise<boolean>;
}

export default function ProfileView({ user, onUpdateProfile }: ProfileProps) {
  const defaultProfile: UserProfile = user.profile || {
    phone_number: "",
    preferred_language: "en",
    home_latitude: "28.6304",
    home_longitude: "77.2177",
    work_latitude: "28.6922",
    work_longitude: "77.2078",
  };

  const [phone, setPhone] = useState(defaultProfile.phone_number);
  const [lang, setLang] = useState(defaultProfile.preferred_language);
  const [homeLat, setHomeLat] = useState(defaultProfile.home_latitude);
  const [homeLng, setHomeLng] = useState(defaultProfile.home_longitude);
  const [workLat, setWorkLat] = useState(defaultProfile.work_latitude);
  const [workLng, setWorkLng] = useState(defaultProfile.work_longitude);
  
  const [saving, setSaving] = useState(false);
  const [savedOk, setSavedOk] = useState(false);

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSavedOk(false);

    try {
      const ok = await onUpdateProfile({
        phone_number: phone,
        preferred_language: lang,
        home_latitude: homeLat,
        home_longitude: homeLng,
        work_latitude: workLat,
        work_longitude: workLng,
      });
      if (ok) {
        setSavedOk(true);
        setTimeout(() => setSavedOk(false), 3000);
      } else {
        alert("Server failed to update profile properties.");
      }
    } catch (err) {
      alert("Error saving profile details.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2 font-sans">
        <UserIcon className="w-5 h-5 text-blue-600" />
        Prepaid Account Settings & Saved Locations
      </h2>

      <div className="max-w-3xl bg-white border border-slate-200 p-6 rounded-xl shadow-sm font-sans">
        <form onSubmit={handleProfileSubmit} className="space-y-6">
          {/* General Bio Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Email Registration</label>
              <input
                type="text"
                value={user.email}
                className="w-full bg-slate-100 border border-slate-200 text-xs text-slate-500 rounded-xl px-4 py-3 outline-none cursor-not-allowed font-mono"
                disabled
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">User Access Level</label>
              <input
                type="text"
                value={`${user.role} Privilege`}
                className="w-full bg-slate-100 border border-slate-200 text-xs text-blue-700 rounded-xl px-4 py-3 outline-none cursor-not-allowed font-mono uppercase font-extrabold"
                disabled
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Phone Contact</label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  placeholder="+91 99999 88888"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-xs text-slate-800 rounded-xl pl-10 pr-4 py-3 outline-none transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Preferred Language</label>
              <div className="relative">
                <Globe className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <select
                  value={lang}
                  onChange={(e) => setLang(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-xs text-slate-800 pr-10 pl-10 py-3.5 rounded-xl outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition"
                >
                  <option value="en">English (Official Commute Interface)</option>
                  <option value="hi">हिन्दी (Hindi NCR Local Interface)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Saved Geolocation Coordinate offsets */}
          <div className="border-t border-slate-200 pt-5 space-y-4">
            <div>
              <h3 className="text-xs font-bold text-slate-800 mb-0.5 uppercase tracking-wider font-sans">Pre-set Saved Landmarks</h3>
              <p className="text-[11px] text-slate-500 leading-relaxed font-sans">
                Store latitude & longitude values modeling home and job catchments to plan transit sequences quickly.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Home location coordinates */}
              <div className="p-4.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3 shadow-sm font-sans">
                <p className="text-xs font-bold text-blue-700 flex items-center gap-1.5 font-sans uppercase tracking-wider">
                  <Home className="w-3.5 h-3.5 text-blue-600" />
                  Home Catchment Hub
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[9px] text-slate-500 font-bold block mb-1">Latitude</label>
                    <input
                      type="text"
                      value={homeLat}
                      onChange={(e) => setHomeLat(e.target.value)}
                      className="w-full bg-white border border-slate-200 text-xs text-slate-800 py-1.5 px-2.5 rounded font-mono outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] text-slate-500 font-bold block mb-1">Longitude</label>
                    <input
                      type="text"
                      value={homeLng}
                      onChange={(e) => setHomeLng(e.target.value)}
                      className="w-full bg-white border border-slate-200 text-xs text-slate-800 py-1.5 px-2.5 rounded font-mono outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Work location coordinates */}
              <div className="p-4.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3 shadow-sm font-sans">
                <p className="text-xs font-bold text-indigo-705 flex items-center gap-1.5 font-sans uppercase tracking-wider">
                  <Briefcase className="w-3.5 h-3.5 text-indigo-600" />
                  Office Catchment Hub
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[9px] text-slate-500 font-bold block mb-1">Latitude</label>
                    <input
                      type="text"
                      value={workLat}
                      onChange={(e) => setWorkLat(e.target.value)}
                      className="w-full bg-white border border-slate-200 text-xs text-slate-800 py-1.5 px-2.5 rounded font-mono outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] text-slate-500 font-bold block mb-1">Longitude</label>
                    <input
                      type="text"
                      value={workLng}
                      onChange={(e) => setWorkLng(e.target.value)}
                      className="w-full bg-white border border-slate-200 text-xs text-slate-800 py-1.5 px-2.5 rounded font-mono outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Actions button */}
          <div className="border-t border-slate-200 pt-5 flex items-center justify-between">
            <span className="text-[11px] text-slate-500 font-medium leading-none">
              Updates require real token authentication.
            </span>

            <div className="flex items-center gap-3">
              {savedOk && (
                <div className="flex items-center gap-1 text-emerald-700 text-xs font-semibold animate-fadeIn">
                  <CheckCircle2 className="w-4 h-4 text-emerald-605" />
                  Profile Synchronized!
                </div>
              )}
              
              <button
                type="submit"
                id="profile-save-submit"
                disabled={saving}
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold transition rounded-xl py-3 px-6 text-xs flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <ShieldCheck className="w-4 h-4 text-white hover:rotate-12 transition duration-200" />
                {saving ? "Encrypting changes..." : "Save Profile details"}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
export {}
