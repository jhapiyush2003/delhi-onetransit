// src/views/AdminDashboard.tsx
import React, { useEffect, useState } from "react";
import { 
  ShieldCheck, Users, ClipboardList, PlusCircle, CheckCircle2, Ticket, Sparkles, Navigation, Layers
} from "lucide-react";
import { User, WalletTransaction } from "../types";

interface AdminDashboardProps {
  adminUser: User;
  onFetchUsers: () => Promise<User[]>;
  onFetchTransactions: () => Promise<WalletTransaction[]>;
}

export default function AdminDashboard({ adminUser, onFetchUsers, onFetchTransactions }: AdminDashboardProps) {
  const [users, setUsers] = useState<User[]>([]);
  const [txs, setTxs] = useState<WalletTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"users" | "txs" | "transit">("users");

  // Manual Station adding form
  const [stName, setStName] = useState("");
  const [stLat, setStLat] = useState("28.6");
  const [stLng, setStLng] = useState("77.2");
  const [feedback, setFeedback] = useState("");

  useEffect(() => {
    let active = true;
    const loadAdminDetails = async () => {
      try {
        const uList = await onFetchUsers();
        const tList = await onFetchTransactions();
        if (active) {
          setUsers(uList);
          setTxs(tList);
        }
      } catch (err) {
        console.error("Admin data hydration failed:", err);
      } finally {
        if (active) setLoading(false);
      }
    };
    loadAdminDetails();
    return () => { active = false; };
  }, [onFetchUsers, onFetchTransactions]);

  const handleCreateStation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!stName) return;
    setFeedback(`Station "${stName}" has been seeded successfully into the Delhi relative graph models!`);
    setStName("");
    setTimeout(() => setFeedback(""), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Admin Title banner */}
      <section className="bg-white border border-slate-205 p-6 rounded-xl flex items-center justify-between shadow-sm font-sans">
        <div className="space-y-1">
          <p className="text-xs font-bold text-red-650 uppercase tracking-widest flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-red-600" /> Administrative privileges enabled
          </p>
          <h2 className="text-xl font-extrabold text-slate-800 tracking-tight">OneTransit Control Center & Audit Desk</h2>
          <p className="text-xs text-slate-500 font-sans leading-relaxed">
            Full-stack auditing of virtual databases, credit pipelines, and graph configurations.
          </p>
        </div>
        <span className="hidden md:inline px-3 py-1 bg-red-50 border border-red-200 text-red-700 text-xxs font-mono rounded font-bold uppercase tracking-widest">
          MASTER ADMIN ACTIVE
        </span>
      </section>

      {/* Tabs controllers */}
      <div className="flex border-b border-slate-200 gap-4 text-xs font-sans">
        <button
          onClick={() => setActiveTab("users")}
          id="admin-tab-users"
          className={`pb-3 font-bold transition cursor-pointer flex items-center gap-1.5 px-1 ${
            activeTab === "users" ? "border-b-2 border-blue-600 text-blue-600" : "text-slate-550 hover:text-slate-800"
          }`}
        >
          <Users className="w-4 h-4" />
          Prepaid Accounts ({users.length})
        </button>

        <button
          onClick={() => setActiveTab("txs")}
          id="admin-tab-txs"
          className={`pb-3 font-bold transition cursor-pointer flex items-center gap-1.5 px-1 ${
            activeTab === "txs" ? "border-b-2 border-blue-600 text-blue-600" : "text-slate-550 hover:text-slate-800"
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          Master Ledger Stream ({txs.length})
        </button>

        <button
          onClick={() => setActiveTab("transit")}
          id="admin-tab-transit"
          className={`pb-3 font-bold transition cursor-pointer flex items-center gap-1.5 px-1 ${
            activeTab === "transit" ? "border-b-2 border-blue-600 text-blue-600" : "text-slate-550 hover:text-slate-800"
          }`}
        >
          <Layers className="w-4 h-4" />
          Network Configurations
        </button>
      </div>

      {loading ? (
        <div className="text-center py-10 text-slate-500 font-mono text-xxs animate-pulse">
          Hydrating server logs master list...
        </div>
      ) : (
        <>
          {activeTab === "users" && (
            <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm animate-fadeIn">
              <h3 className="text-sm font-bold text-slate-800 mb-4 font-sans">Passenger Directory (Neon database simulated)</h3>
              
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xxs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-150 text-slate-500 font-mono uppercase tracking-wider text-[10px]">
                      <th className="py-2.5 font-bold">User Details</th>
                      <th className="py-2.5 font-bold">Account Email</th>
                      <th className="py-2.5 font-bold">Privilege role</th>
                      <th className="py-2.5 font-bold">Status Check</th>
                      <th className="py-2.5 font-bold">Created Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-650 text-xs font-sans">
                    {users.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-50">
                        <td className="py-3 font-semibold text-slate-800">{u.full_name}</td>
                        <td className="py-3 font-mono text-slate-500 text-[11px]">{u.email}</td>
                        <td className="py-3">
                          <span className={`px-2 py-0.5 rounded text-[9px] font-bold font-mono tracking-wider ${
                            u.role === "Admin" ? "bg-red-50 text-red-700 border border-red-155" : "bg-blue-50 text-blue-700 border border-blue-155"
                          }`}>
                            {u.role.toUpperCase()}
                          </span>
                        </td>
                        <td className="py-3">
                          <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-150 text-[10px] rounded font-bold uppercase">
                            {u.status.toUpperCase()}
                          </span>
                        </td>
                        <td className="py-3 text-[11px] text-slate-500">{new Date(u.created_at).toLocaleDateString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === "txs" && (
            <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm animate-fadeIn">
              <h3 className="text-sm font-bold text-slate-800 mb-4 font-sans">Master Ledger Pipeline</h3>
              
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xxs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-150 text-slate-500 font-mono uppercase tracking-wider text-[10px]">
                      <th className="py-2.5 font-bold">Transaction ID</th>
                      <th className="py-2.5 font-bold">Passenger Node</th>
                      <th className="py-2.5 font-bold">Description</th>
                      <th className="py-2.5 font-bold">Status</th>
                      <th className="py-2.5 font-bold text-right">Debit/Credit</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-650 text-xs font-sans">
                    {txs.map((tx) => (
                      <tr key={tx.id} className="hover:bg-slate-50">
                        <td className="py-3 font-mono text-slate-500 text-[11px]">{tx.reference_id}</td>
                        <td className="py-3 text-slate-700 font-sans">
                          <div className="font-semibold text-slate-800">{tx.user_name || "Prepaid Account"}</div>
                          <div className="text-[10px] text-slate-500 font-mono mt-0.5">{tx.user_email}</div>
                        </td>
                        <td className="py-3">{tx.description}</td>
                        <td className="py-3">
                          <span className="px-2 py-0.5 bg-emerald-50 border border-emerald-150 text-emerald-705 text-[10px] rounded font-bold uppercase">
                            {tx.status}
                          </span>
                        </td>
                        <td className={`py-3 text-right font-bold font-mono text-xs ${
                          tx.transaction_type === "credit" || tx.transaction_type === "refund" ? "text-emerald-700" : "text-red-650"
                        }`}>
                          {tx.transaction_type === "credit" || tx.transaction_type === "refund" ? "+" : "-"}₹{tx.amount}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === "transit" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fadeIn font-sans">
              {/* Form to insert new Metro coordinate station */}
              <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm">
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-4">
                  <PlusCircle className="w-4 h-4 text-blue-600" />
                  Seed Metro Station
                </h3>

                <form onSubmit={handleCreateStation} className="space-y-4">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Station Landmark Name</label>
                    <input
                      type="text"
                      placeholder="e.g., Lajpat Nagar"
                      value={stName}
                      onChange={(e) => setStName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-xs text-slate-800 py-3.5 px-4 rounded-xl outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Latitude Coordinate</label>
                      <input
                        type="text"
                        value={stLat}
                        onChange={(e) => setStLat(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 text-xs text-slate-800 py-3 px-4 rounded-xl font-mono outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Longitude Coordinate</label>
                      <input
                        type="text"
                        value={stLng}
                        onChange={(e) => setStLng(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 text-xs text-slate-800 py-3 px-4 rounded-xl font-mono outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  {feedback && (
                    <div className="flex items-center gap-2 px-3.5 py-2 bg-emerald-50 border border-emerald-150 text-emerald-700 rounded-xl text-xxs">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>{feedback}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 px-4 rounded-xl text-xs transition cursor-pointer shadow-sm"
                  >
                    Insert Station Database Row
                  </button>
                </form>
              </div>

              {/* Transit Systems Status Readouts */}
              <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-4 shadow-sm">
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <Navigation className="w-4 h-4 text-blue-600 animate-pulse" />
                  Live NCR Service Feeders
                </h3>

                <div className="space-y-2.5">
                  {[
                    { mode: "Delhi Metro (DMRC)", status: "Operational", co2: "135.5g/km offset", state: "text-emerald-700 bg-emerald-50 border-emerald-150" },
                    { mode: "DTC Green Buses", status: "Operational", co2: "128g/km offset", state: "text-emerald-700 bg-emerald-50 border-emerald-150" },
                    { mode: "Local Trains (EMU)", status: "Active (2 Min Delay)", co2: "122g/km offset", state: "text-amber-700 bg-amber-50 border-amber-150" },
                    { mode: "E-Rickshaws (Feeder)", status: "Active Hub Zones", co2: "138g/km offset", state: "text-emerald-700 bg-emerald-50 border-emerald-150" },
                  ].map((sys, idx) => (
                    <div key={idx} className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                      <div>
                        <p className="text-xs font-bold text-slate-800">{sys.mode}</p>
                        <span className="text-[10px] text-slate-550 font-mono mt-0.5 block">{sys.co2}</span>
                      </div>
                      <span className={`px-2.5 py-1 rounded text-[10px] font-bold font-mono border ${sys.state}`}>
                        {sys.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
// 
