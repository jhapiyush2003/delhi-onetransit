// src/views/RoutePlanner.tsx
import React, { useState } from "react";
import { 
  Search, ArrowRight, CornerDownRight, Leaf, ShieldAlert, Sparkles, Navigation, CreditCard, ShieldCheck, TicketCheck
} from "lucide-react";
import MapCanvas from "../components/MapCanvas";
import { User, Wallet, MultimodalRouteResponse, TravelTripLeg, TravelTrip } from "../types";

// Standard Delhi Landmarks list
const STATIONS = [
  "Rajiv Chowk", "Kashmere Gate", "GTB Nagar", "HUDA City Centre",
  "Noida Sector 62", "Hazrat Nizamuddin", "New Delhi Station", "Anand Vihar"
];

interface RoutePlannerProps {
  user: User;
  wallet: Wallet | null;
  onSearch: (src: string, dst: string, priority: string) => Promise<MultimodalRouteResponse | null>;
  onSaveTrip: (trip: Omit<TravelTrip, "id">) => Promise<boolean>;
  setView: (view: string) => void;
  guestRouteResult: MultimodalRouteResponse | null;
}

export default function RoutePlanner({ user, wallet, onSearch, onSaveTrip, setView, guestRouteResult }: RoutePlannerProps) {
  const [source, setSource] = useState("Rajiv Chowk");
  const [destination, setDestination] = useState("GTB Nagar");
  const [priority, setPriority] = useState("fastest");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MultimodalRouteResponse | null>(guestRouteResult);
  const [errText, setErrText] = useState("");
  const [booking, setBooking] = useState(false);
  const [booked, setBooked] = useState(false);

  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (source === destination) {
      setErrText("Origin and destination stations cannot match.");
      return;
    }
    setLoading(true);
    setErrText("");
    setBooked(false);

    try {
      const res = await onSearch(source, destination, priority);
      if (res) {
        setResult(res);
      } else {
        setErrText("Failed to compile route path.");
      }
    } catch (err) {
      setErrText("Server route query timed out.");
    } finally {
      setLoading(false);
    }
  };

  const handleBookJourney = async () => {
    if (!result) return;
    
    // Check wallet balance
    if (wallet && wallet.balance < result.total_fare) {
      alert("Insufficient balance in your Delhi OneTransit wallet. Please recharge.");
      setErrText("Insufficient balance. Direct recharge available in Smart Wallet.");
      return;
    }

    setBooking(true);
    setErrText("");

    try {
      const tripRequest: Omit<TravelTrip, "id"> = {
        source_address: source,
        destination_address: destination,
        total_fare: result.total_fare,
        total_distance_km: result.total_distance_km,
        total_duration_minutes: result.total_duration_minutes,
        co2_saved_g: result.carbon_saved_g,
        start_time: new Date().toISOString(),
        end_time: new Date(Date.now() + result.total_duration_minutes * 60 * 1000).toISOString(),
        legs: result.legs.map((leg) => ({
          transport_code: leg.transport_mode,
          source_name: leg.source_name,
          destination_name: leg.destination_name,
          fare: leg.fare,
          distance_km: leg.distance_km,
          duration_minutes: leg.duration_minutes,
          line_name: leg.line_name,
          route_code: leg.route_code
        }))
      };

      const ok = await onSaveTrip(tripRequest);
      if (ok) {
        setBooked(true);
      } else {
        setErrText("Failed to register and pay ticket. Please recharge balance.");
      }
    } catch (err) {
      setErrText("Network error logging ticket.");
    } finally {
      setBooking(false);
    }
  };

  // Maps transport modes codes to background accents
  const getModeStyles = (code: string) => {
    switch (code) {
      case "METRO": return "bg-blue-50 text-blue-700 border-blue-200";
      case "BUS": return "bg-emerald-50 text-emerald-700 border-emerald-200";
      case "TRAIN": return "bg-indigo-50 text-indigo-700 border-indigo-250";
      case "RICKSHAW": return "bg-amber-50 text-amber-750 border-amber-200";
      default: return "bg-slate-50 text-slate-600 border-slate-200";
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
        <Navigation className="w-5 h-5 text-blue-600 animate-pulse" />
        Multi-Modal Dijkstra Route Planner
      </h2>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Left routing searches panel */}
        <div className="xl:col-span-5 space-y-6">
          <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm">
            <form onSubmit={handleSearchSubmit} className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-450 uppercase tracking-wide mb-1.5">Origin Landmark</label>
                <select
                  value={source}
                  onChange={(e) => setSource(e.target.value)}
                  id="search-src-select"
                  className="w-full bg-slate-50 border border-slate-200 text-xs text-slate-705 rounded-xl px-4 py-3 outline-none transition focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                >
                  {STATIONS.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-450 uppercase tracking-wide mb-1.5">Destination Landmark</label>
                <select
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  id="search-dst-select"
                  className="w-full bg-slate-50 border border-slate-200 text-xs text-slate-705 rounded-xl px-4 py-3 outline-none transition focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                >
                  {STATIONS.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>

              {/* Priority Optimization Selector */}
              <div>
                <label className="block text-[11px] font-bold text-slate-450 uppercase tracking-wide mb-1.5">Dijkstra Optimizer Weights</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: "fastest", label: "Fastest Route" },
                    { id: "cheapest", label: "Cheapest Fare" },
                    { id: "minimum_interchanges", label: "Least Switches" },
                    { id: "lowest_walking", label: "Lowest Walk" }
                  ].map((fOpt) => (
                    <button
                      key={fOpt.id}
                      type="button"
                      onClick={() => setPriority(fOpt.id)}
                      className={`
                        py-2.5 px-3 border rounded-xl text-[11px] font-semibold transition-all text-center cursor-pointer
                        ${priority === fOpt.id 
                          ? "bg-blue-50/70 border-blue-500 text-blue-700 font-bold" 
                          : "bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100"
                        }
                      `}
                    >
                      {fOpt.label}
                    </button>
                  ))}
                </div>
              </div>

              {errText && (
                <div className="flex items-center gap-2 px-3 py-2 bg-red-50 border border-red-100 rounded-lg text-red-650 text-xs">
                  <ShieldAlert className="w-4 h-4 text-red-500" />
                  <span>{errText}</span>
                </div>
              )}

              <button
                type="submit"
                id="search-submit"
                disabled={loading}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-sm"
              >
                <Search className="w-4 h-4 text-white" />
                {loading ? "Searching Graph Nodes..." : "Compute Routes Selection"}
              </button>
            </form>
          </div>

          {/* Map canvas container */}
          <MapCanvas highlightLegs={result ? result.legs : []} />
        </div>

        {/* Right Solved Route outputs */}
        <div className="xl:col-span-7 space-y-6">
          {result ? (
            <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-6 shadow-sm relative">
              {/* Aggregates Board */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200 shadow-inner">
                <div>
                  <p className="text-[10px] text-slate-455 font-mono uppercase tracking-wider">Total Tickets Fare</p>
                  <p className="text-base font-extrabold text-blue-605 mt-0.5">₹{result.total_fare}</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-455 font-mono uppercase tracking-wider">Travel Time</p>
                  <p className="text-base font-extrabold text-slate-800 mt-0.5">{result.total_duration_minutes} mins</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-455 font-mono uppercase tracking-wider">Total Distance</p>
                  <p className="text-base font-extrabold text-slate-800 mt-0.5">{result.total_distance_km} km</p>
                </div>
                <div className="text-emerald-700 font-semibold leading-none">
                  <p className="text-[10px] text-slate-455 font-mono leading-none flex items-center gap-1 uppercase tracking-wider">
                    <Leaf className="w-3.5 h-3.5 text-emerald-600" /> Carbon Saved
                  </p>
                  <p className="text-base font-extrabold text-emerald-650 mt-0.5">
                    {result.carbon_saved_g}g
                  </p>
                </div>
              </div>

              {/* Legs list mapping */}
              <div className="space-y-4">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Segmental Trip Directions</h3>
                
                <div className="relative border-l-2 border-slate-150 pl-4.5 ml-2.5 space-y-5">
                  {result.legs.map((leg, idx) => (
                    <div key={idx} className="relative space-y-1">
                      {/* Node circle locator */}
                      <span className="absolute -left-[24.5px] top-1 w-3 h-3 bg-white border-2 border-blue-500 rounded-full" />
                      
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`px-1.5 py-0.5 text-xxxs font-mono rounded border uppercase font-bold tracking-wider ${getModeStyles(leg.transport_mode)}`}>
                          {leg.transport_mode}
                        </span>
                        
                        {leg.line_name && (
                          <span className="text-[10px] bg-slate-50 text-slate-600 border border-slate-200 px-1.5 py-0.5 rounded font-mono">
                            {leg.line_name}
                          </span>
                        )}
                        {leg.route_code && (
                          <span className="text-[10px] bg-slate-50 text-slate-605 border border-slate-200 px-1.5 py-0.5 rounded font-mono">
                            Bus: {leg.route_code}
                          </span>
                        )}

                        <span className="text-xxs text-slate-400 font-mono ml-auto font-medium">
                          {leg.distance_km}km &middot; {leg.duration_minutes} min &middot; ₹{leg.fare}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600">
                        From <span className="font-semibold text-slate-800">{leg.source_name}</span> to <span className="font-semibold text-slate-800">{leg.destination_name}</span>
                      </p>
                    </div>
                  ))}
                  
                  {/* Destination anchor terminal */}
                  <div className="relative">
                    <span className="absolute -left-[24.5px] top-1 w-3.5 h-3.5 bg-white border-2 border-emerald-500 rounded-full" />
                    <p className="text-xs font-bold text-emerald-600">Arrived at {destination}</p>
                  </div>
                </div>
              </div>

              {/* Ticketing transactions section */}
              <div className="border-t border-slate-150 pt-5 flex items-center justify-between">
                <div className="text-[11px] text-slate-500 max-w-sm">
                  <span className="font-semibold block text-slate-700">Ticketing Wallet confirmation</span>
                  Charges are debited atomically from your OneTransit balance.
                </div>

                {booked ? (
                  <div className="flex items-center gap-2 px-3.5 py-2.5 bg-emerald-50 border border-emerald-150 text-emerald-700 rounded-xl text-xs font-bold shadow-sm">
                    <TicketCheck className="w-5 h-5 text-emerald-650 animate-bounce" />
                    Commute Logged & Ticket Issued!
                  </div>
                ) : (
                  <button
                    onClick={handleBookJourney}
                    disabled={booking}
                    id="planner-book-journey"
                    className="bg-blue-600 text-white font-bold hover:bg-blue-700 transition rounded-xl py-3 px-4.5 text-xs flex items-center gap-2 cursor-pointer shadow-sm animate-fadeIn"
                  >
                    <CreditCard className="w-4 h-4 text-white" />
                    {booking ? "Deducting Fares..." : `Purchase Ticket (₹${result.total_fare})`}
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl p-12 text-center text-slate-400 space-y-2 shadow-sm">
              <Sparkles className="w-8 h-8 text-blue-500 block mx-auto animate-pulse" />
              <p className="text-xs font-semibold text-slate-600">Pending search inputs query parameters</p>
              <p className="text-xxs text-slate-450">Submit origin & destination stations above to view optimal paths.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
