// src/views/Login.tsx
import React, { useState } from "react";
import { Train, Mail, Lock, ShieldAlert, ArrowRight, ShieldCheck, Sparkles } from "lucide-react";

interface LoginProps {
  setView: (view: string) => void;
  onLogin: (email: string, password: string) => Promise<boolean>;
}

export default function Login({ setView, onLogin }: LoginProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorText, setErrorText] = useState("");

  const handleBypass = () => {
    // Inject recruiter admin credentials instantly
    setEmail("recruiter@onetransit.in");
    setPassword("recruiter123");
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setErrorText("Email and password fields are required.");
      return;
    }
    setLoading(true);
    setErrorText("");

    try {
      const success = await onLogin(email, password);
      if (!success) {
        setErrorText("Incorrect email or password combination.");
      }
    } catch (err: any) {
      setErrorText(err?.message || "Server gateway timed out.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-50 text-slate-800 min-h-screen flex items-center justify-center p-4 relative overflow-hidden font-sans">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(37,99,235,0.06),transparent_60%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:24px_24px] opacity-60 pointer-events-none" />

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-md bg-white border border-slate-200 rounded-2xl p-6 md:p-8 shadow-md space-y-6">
        {/* Brand Banner */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center bg-blue-600 p-2.5 rounded-xl text-white shadow-sm">
            <Train className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-lg font-bold text-slate-800 tracking-tight">OneTransit Platform</h2>
          <p className="text-xs text-slate-500">Sign in to manage and recharge smart credentials</p>
        </div>

        {errorText && (
          <div className="flex items-center gap-2 px-3 py-2.5 bg-red-50 border border-red-100 rounded-xl text-red-600 text-xs">
            <ShieldAlert className="w-4 h-4 text-red-500 shrink-0" />
            <span>{errorText}</span>
          </div>
        )}

        <form onSubmit={handleLoginSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-bold text-slate-450 uppercase tracking-wide mb-1.5">Registered Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="email"
                placeholder="email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                id="login-email"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-700 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition"
                required
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between mb-1.5">
              <label className="block text-[11px] font-bold text-slate-450 uppercase tracking-wide">Password Secret</label>
              <button
                type="button"
                className="text-[11px] font-medium text-blue-600 hover:underline cursor-pointer"
                onClick={() => alert("Secret Key is logged as 'recruiter123' inside this sandbox")}
              >
                Forgot Password?
              </button>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                id="login-password"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-700 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            id="login-submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-sm"
          >
            {loading ? "Decrypting Session..." : "Sign In to Gateway"}
            <ArrowRight className="w-4 h-4 text-white" />
          </button>
        </form>

        {/* Recruiter One-Click Fast-Track Entry */}
        <div className="border-t border-slate-150 pt-4 space-y-3">
          <div className="text-center">
            <span className="text-[10px] font-mono tracking-widest text-slate-405 uppercase block mb-1">
              Recruiter Quick Access Seeding
            </span>
          </div>

          <button
            type="button"
            id="login-quick-recruiter"
            onClick={handleBypass}
            className="w-full bg-blue-50/50 border border-blue-250/80 hover:bg-blue-50 text-blue-700 font-bold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4 text-blue-600" />
            Prefill Recruiter Credentials
            <Sparkles className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
          </button>
        </div>

        <p className="text-xs text-center text-slate-500">
          Want a new credentials account?{" "}
          <button onClick={() => setView("signup")} id="login-goto-signup" className="text-blue-600 font-semibold hover:underline cursor-pointer">
            Create Account
          </button>
        </p>
      </div>
    </div>
  );
}
