// src/views/Wallet.tsx
import React, { useState } from "react";
import { 
  CreditCard, Sparkles, Navigation, Send, ArrowUpRight, History, CalendarRange, Check, ShieldCheck, Ticket
} from "lucide-react";
import { User, Wallet, WalletTransaction, TransitPass } from "../types";

interface WalletProps {
  user: User;
  wallet: Wallet | null;
  transactions: WalletTransaction[];
  activePasses: TransitPass[];
  onRecharge: (amount: number, method: string) => Promise<boolean>;
  onBuyPass: (passType: string, mode: string, price: number) => Promise<boolean>;
}

// Available subscriptions passes list
const AVAILABLE_PASSES = [
  { id: "dm-t30", name: "DMRC 30-Day Monthly Pass", mode: "METRO", price: 850.0, desc: "Unlimited travel across all Delhi Metro lines including Airport Express." },
  { id: "dtc-ac", name: "DTC AC Bus Monthly Pass", mode: "BUS", price: 250.0, desc: "Unlimited rides on DTC low-floor environment-friendly CNG AC red buses." },
  { id: "emu-pass", name: "Suburban EMU Monthly Pass", mode: "TRAIN", price: 150.0, desc: "Commuter general ticket pass connecting outer NCR rail lines." }
];

export default function WalletView({ user, wallet, transactions, activePasses, onRecharge, onBuyPass }: WalletProps) {
  const [rechargeAmt, setRechargeAmt] = useState("");
  const [payMethod, setPayMethod] = useState("UPI");
  const [loadingTopUp, setLoadingTopUp] = useState(false);
  const [buyingPassId, setBuyingPassId] = useState<string | null>(null);

  const handleTopup = async (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(rechargeAmt);
    if (!val || val <= 0 || val > 5000) {
      alert("Please enter a valid top-up value between ₹10 and ₹5000.");
      return;
    }
    setLoadingTopUp(true);
    const ok = await onRecharge(val, payMethod);
    if (ok) {
      alert(`Successfully recharged card with ₹${val}`);
      setRechargeAmt("");
    } else {
      alert("Topup gateway rejected transaction. Please check profile status.");
    }
    setLoadingTopUp(false);
  };

  const handleBuyPass = async (pass: typeof AVAILABLE_PASSES[0]) => {
    if (!wallet || wallet.balance < pass.price) {
      alert("Insufficient funds! Top-up your prepaid smart card wallet first.");
      return;
    }

    const conf = window.confirm(`Deduct ₹${pass.price} from your wallet to buy "${pass.name}"?`);
    if (!conf) return;

    setBuyingPassId(pass.id);
    const ok = await onBuyPass(pass.name, pass.mode, pass.price);
    if (ok) {
      alert(`Subscription activated: ${pass.name}! Valid for 30 days.`);
    } else {
      alert("Transaction declined. Try recharging your wallet first.");
    }
    setBuyingPassId(null);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
        <CreditCard className="w-5 h-5 text-blue-600" />
        Unified Smart Wallet & Digital Passes
      </h2>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left column: wallet balance & recharge */}
        <div className="lg:col-span-4 space-y-6">
          {/* Card representation */}
          <div className="bg-gradient-to-br from-blue-700 via-blue-600 to-blue-800 border border-blue-500 rounded-2xl p-6 relative overflow-hidden flex flex-col justify-between h-48 shadow-md">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-2xl font-sans" />
            
            <div className="flex items-center justify-between z-10 font-sans">
              <span className="text-xxs font-mono text-blue-150 font-extrabold uppercase tracking-widest">ONE CARD DELHI</span>
              <Ticket className="w-5 h-5 text-blue-150" />
            </div>

            <div className="z-10 font-sans">
              <p className="text-[10px] text-white/70 font-mono text-left uppercase tracking-wider font-semibold">AVAILABLE VALUE</p>
              <h3 className="text-2xl font-extrabold text-white font-mono mt-0.5 tracking-tight">
                ₹{wallet ? wallet.balance.toFixed(2) : "0.00"}
              </h3>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-white/10 z-10 text-[10px] text-white/90 font-mono uppercase">
              <div>
                <p className="text-[8px] text-white/50">CARD OWNER</p>
                <p className="text-white font-medium">{user.full_name}</p>
              </div>
              <span className="px-2 py-0.5 bg-white/20 border border-white/10 text-white rounded font-bold">ACTIVE</span>
            </div>
          </div>

          {/* Top-Up form */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm">
            <h3 className="text-xs font-bold text-slate-800 mb-3 uppercase tracking-wider font-sans">Recharge One Card Gateway</h3>
            
            <form onSubmit={handleTopup} className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-450 uppercase tracking-wide mb-1.5 font-semibold font-sans">Funding Amount (INR)</label>
                <input
                  type="number"
                  placeholder="500"
                  value={rechargeAmt}
                  onChange={(e) => setRechargeAmt(e.target.value)}
                  id="wallet-recharge-input"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-xs text-slate-850 rounded-xl px-4 py-3 outline-none font-mono"
                  disabled={loadingTopUp}
                  min="10"
                  max="5000"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-450 uppercase tracking-wide mb-1.5 font-semibold font-sans">Funding Method</label>
                <select
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-xs text-slate-850 rounded-xl px-4 py-3 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                >
                  <option value="UPI">UPI (GooglePay / PhonePe / Paytm)</option>
                  <option value="NetBanking">NetBanking (SBI, HDFC, ICICI)</option>
                  <option value="CreditCard">Credit/Debit Card (Visa / MasterCard)</option>
                </select>
              </div>

              <button
                type="submit"
                id="wallet-recharge-submit"
                disabled={loadingTopUp}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 px-4 rounded-xl text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-sm"
              >
                <ArrowUpRight className="w-4 h-4 text-white" />
                {loadingTopUp ? "Authorizing UPI..." : "Load Funds Gateway"}
              </button>
            </form>
          </div>
        </div>

        {/* Right column: Passes Store & Transaction ledger */}
        <div className="lg:col-span-8 space-y-6">
          {/* Subscription Pass Store */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-4 font-sans">
              <CalendarRange className="w-4 h-4 text-blue-600" />
              Dynamic Smart Subscription Pass Shop
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {AVAILABLE_PASSES.map((pass) => {
                const isActive = activePasses.some((p) => p.pass_type === pass.name);
                return (
                  <div key={pass.id} className="bg-slate-50 border border-slate-200 p-4 rounded-xl flex flex-col justify-between space-y-3 relative overflow-hidden shadow-sm">
                    {isActive && (
                      <div className="absolute top-0 right-0 bg-emerald-600 text-white text-[8px] font-mono font-bold px-2.5 py-0.5 rounded-bl uppercase">
                        Active Pass
                      </div>
                    )}
                    
                    <div className="space-y-1">
                      <h4 className="text-xs font-bold text-slate-800 font-sans">{pass.name}</h4>
                      <p className="text-[11px] text-slate-500 leading-relaxed font-sans">{pass.desc}</p>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-200/60">
                      <span className="text-sm font-extrabold text-blue-650 font-mono">₹{pass.price}</span>
                      <button
                        onClick={() => handleBuyPass(pass)}
                        disabled={isActive || buyingPassId === pass.id}
                        className={`
                          py-1.5 px-2.5 rounded-lg text-[10px] font-bold transition flex items-center gap-1 cursor-pointer font-sans
                          ${isActive 
                            ? "bg-slate-200 text-slate-500 border border-slate-350" 
                            : "bg-blue-600 hover:bg-blue-700 text-white shadow-sm"
                          }
                        `}
                      >
                        {isActive ? <Check className="w-3.5 h-3.5 text-emerald-650 font-bold" /> : null}
                        {isActive ? "Owned" : buyingPassId === pass.id ? "Securing..." : "Subscribe"}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Transactions Ledger Card */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm">
            <h3 className="text-xs font-bold text-slate-800 flex items-center gap-2 mb-4 uppercase tracking-wider font-sans">
              <History className="w-4 h-4 text-slate-500" />
              Smart prepaid transactions Ledger
            </h3>

            {transactions.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xxs font-sans">
                No ledger transactions found under this card profile
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xxs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-150 text-slate-500 font-mono uppercase tracking-wider text-[10px]">
                      <th className="py-2.5 font-bold">Description</th>
                      <th className="py-2.5 font-bold">Payment ID / Ref</th>
                      <th className="py-2.5 font-bold">Timestamp</th>
                      <th className="py-2.5 font-bold text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-650 text-xs font-sans">
                    {transactions.map((tx) => (
                      <tr key={tx.id} className="hover:bg-slate-50">
                        <td className="py-3 font-semibold text-slate-800">{tx.description}</td>
                        <td className="py-3 font-mono text-slate-500 text-[11px]">{tx.reference_id || "N/A"}</td>
                        <td className="py-3 text-[11px] text-slate-500">{new Date(tx.created_at).toLocaleDateString()} {new Date(tx.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</td>
                        <td className={`py-3 text-right font-bold font-mono text-xs ${
                          tx.transaction_type === "credit" || tx.transaction_type === "refund" 
                            ? "text-emerald-700" 
                            : "text-red-650"
                        }`}>
                          {tx.transaction_type === "credit" || tx.transaction_type === "refund" ? "+" : "-"}
                          ₹{tx.amount}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
