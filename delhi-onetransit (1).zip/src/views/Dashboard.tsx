// src/views/Dashboard.tsx
import React from "react";
import { 
  CreditCard, Sparkles, Navigation, Send, ArrowUpRight, ShieldCheck, Leaf, Compass, CalendarRange
} from "lucide-react";
import { User, Wallet, TransitPass, DashboardStats } from "../types";

interface DashboardProps {
  user: User;
  wallet: Wallet | null;
  activePasses: TransitPass[];
  analytics: DashboardStats | null;
  setView: (view: string) => void;
  onQuickRecharge: (amount: number) => Promise<boolean>;
}

export default function Dashboard({ user, wallet, activePasses, analytics, setView, onQuickRecharge }: DashboardProps) {
  const [rechargeAmt, setRechargeAmt] = React.useState("200");
  const [isCapping, setIsCapping] = React.useState(false);

  const handleRechargeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(rechargeAmt);
    if (!val || val <= 0 || val > 5000) {
      alert("Invalid funding specifications");
      return;
    }
    setIsCapping(true);
    const ok = await onQuickRecharge(val);
    if (ok) {
      alert(`Top-up of ₹${val} added successfully!`);
    } else {
      alert("Topup gateway issue. Please retry.");
    }
    setIsCapping(false);
  };

  return (
    <div className="space-y-6">
      {/* Brand Greeting Hero Block */}
      <section className="bg-white border border-slate-200 p-6 rounded-xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm font-sans">
        <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500/5 rounded-full blur-3xl z-0" />
        
        <div className="space-y-1 relative z-10">
          <p className="text-[11px] font-bold text-blue-605 uppercase tracking-widest flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" /> Welcome, commuter
          </p>
          <h2 className="text-xl md:text-2xl font-extrabold text-slate-800 tracking-tight">{user.full_name}</h2>
          <p className="text-xs text-slate-500 mt-1">
            Current system status: <span className="text-emerald-600 font-bold">● Active Network Operations</span> &middot; DMRC Yellow/Blue & DTC 502/419/604 live
          </p>
        </div>

        <button
          onClick={() => setView("planner")}
          className="relative z-10 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2.5 px-4.5 rounded-xl flex items-center gap-2 transition cursor-pointer shadow-sm self-start md:self-auto"
        >
          <Compass className="w-4 h-4 text-white" />
          Plan Multi-Modal Journey
        </button>
      </section>

      {/* Main Grid Widgets */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Wallet and Recharge */}
        <section className="lg:col-span-7 space-y-6">
          {/* Smart Card Widget */}
          <div className="bg-gradient-to-br from-blue-700 via-blue-600 to-indigo-850 border border-blue-500 rounded-2xl p-6 relative overflow-hidden shadow-md">
            <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-white/5 rounded-full blur-2xl" />
            
            <div className="flex items-center justify-between mb-8 z-10 relative">
              <div className="flex items-center gap-2.5">
                <CreditCard className="w-5 h-5 text-blue-150" />
                <span className="text-[10px] font-mono text-blue-100 font-bold uppercase tracking-widest">
                  Prepaid smart credentials
                </span>
              </div>
              <span className="text-[9px] font-mono text-white/50 uppercase tracking-widest">DELHI NCR METRO CARD</span>
            </div>

            <div className="space-y-1 z-10 relative">
              <p className="text-[10px] text-white/70 font-mono tracking-wider font-semibold">AVAILABLE CARD BALANCE</p>
              <p className="text-2xl md:text-3xl font-extrabold text-white font-mono tracking-tight">
                ₹{wallet ? wallet.balance.toFixed(2) : "0.00"}
              </p>
            </div>

            <div className="mt-8 flex items-center justify-between border-t border-white/10 pt-4 text-xxs text-white/80 font-mono z-10 relative">
              <div>
                <p className="text-[8px] text-white/55">CARD ID</p>
                <p className="text-white font-medium">{wallet ? wallet.id.substr(0, 14).toUpperCase() : "MOCK-GUEST-ID"}</p>
              </div>
              <div>
                <p className="text-[8px] text-white/55">CARD STATE</p>
                <p className="text-white font-bold uppercase tracking-wider">{wallet ? wallet.status : "ACTIVE"}</p>
              </div>
            </div>
          </div>

          {/* Quick Recharge Panel */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <h3 className="text-xs font-bold text-slate-800 mb-1 uppercase tracking-wider font-sans">Instant Balance Top-Up</h3>
            <p className="text-xs text-slate-500 mb-4 font-sans">Recharge up to ₹5000 via UPI or Debit instant payment gateways.</p>

            <form onSubmit={handleRechargeSubmit} className="grid grid-cols-3 gap-2 items-center">
              <div className="col-span-2 flex items-center bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 relative">
                <span className="text-xs text-slate-550 absolute left-3.5 font-mono">₹</span>
                <input
                  type="number"
                  placeholder="200"
                  value={rechargeAmt}
                  onChange={(e) => setRechargeAmt(e.target.value)}
                  id="dashboard-recharge-input"
                  className="w-full bg-transparent pl-4 border-none outline-none text-xs text-slate-800 font-mono"
                  disabled={isCapping}
                  min="10"
                  max="5000"
                  required
                />
              </div>

              <button
                type="submit"
                id="dashboard-recharge-submit"
                disabled={isCapping}
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold transition rounded-xl py-3 px-3 text-xs flex items-center justify-center gap-1 cursor-pointer shadow-sm"
              >
                Top-Up UPI
                <ArrowUpRight className="w-3.5 h-3.5 text-white" />
              </button>
            </form>

            <div className="mt-4 flex gap-2 justify-start">
              {["100", "200", "500", "1000"].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setRechargeAmt(preset)}
                  className="px-3.5 py-2 bg-slate-50 hover:bg-slate-100 text-slate-650 border border-slate-200 rounded-lg text-xs font-semibold font-mono transition cursor-pointer"
                >
                  +₹{preset}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Right Side: Active Passes and Quick Telemetry */}
        <section className="lg:col-span-5 space-y-6">
          {/* Quick Metrics Cards */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white border border-slate-200 p-4.5 rounded-xl space-y-1 shadow-sm font-sans">
              <span className="text-[10px] text-slate-455 font-bold uppercase tracking-wider">Total Commute Trips</span>
              <p className="text-2xl font-extrabold text-slate-850">
                {analytics ? analytics.total_trips_conducted : "1"}
              </p>
            </div>
            <div className="bg-white border border-slate-200 p-4.5 rounded-xl space-y-1 shadow-sm font-sans">
              <div className="flex items-center gap-1.5 text-emerald-705">
                <Leaf className="w-4 h-4 text-emerald-600" />
                <span className="text-[10px] text-emerald-700 font-bold uppercase tracking-wider">Carbon Offset</span>
              </div>
              <p className="text-2xl font-extrabold text-slate-850">
                {analytics ? `${(analytics.carbon_emissions_saved_g / 1000).toFixed(1)}kg` : "1.5kg"}
              </p>
            </div>
          </div>

          {/* Active Cards Subscriptions */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4 shadow-sm font-sans">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Your Active Digital Passes</h3>
              <CalendarRange className="w-4 h-4 text-slate-400" />
            </div>

            {activePasses.length === 0 ? (
              <div className="text-center py-6 px-4 bg-slate-50 border border-dashed border-slate-200 rounded-xl space-y-2">
                <span className="text-xs text-slate-550 block font-medium">No pre-paid tickets or subscription passes are currently active.</span>
                <button
                  onClick={() => setView("wallet")}
                  className="text-xs text-blue-600 font-bold hover:underline cursor-pointer"
                >
                  Visit smart Pass Shop
                </button>
              </div>
            ) : (
              <div className="space-y-2.5 animate-fadeIn">
                {activePasses.map((pass) => (
                  <div 
                    key={pass.id} 
                    className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between"
                  >
                    <div>
                      <p className="text-xs font-bold text-slate-850">{pass.pass_type}</p>
                      <p className="text-[11px] text-slate-500 mt-1 font-mono">
                        Expires: {new Date(pass.expires_at).toLocaleDateString()}
                      </p>
                    </div>
                    <span className="px-2.5 py-1 bg-emerald-50 border border-emerald-200 text-emerald-700 text-[10px] font-bold uppercase tracking-wider rounded font-mono">
                      ACTIVE
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
