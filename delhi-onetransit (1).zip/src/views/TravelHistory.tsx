// src/views/TravelHistory.tsx
import React, { useState } from "react";
import { History, MapPin, Calendar, Clock, Leaf, CreditCard, ChevronDown, ChevronUp, ArrowRight } from "lucide-react";
import { TravelTrip } from "../types";

interface HistoryProps {
  trips: TravelTrip[];
}

export default function TravelHistory({ trips }: HistoryProps) {
  const [expandedTripId, setExpandedTripId] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    setExpandedTripId(expandedTripId === id ? null : id);
  };

  const getModeLabelColor = (mode: string) => {
    switch (mode) {
      case "METRO": return "text-blue-700 bg-blue-50 border-blue-200";
      case "BUS": return "text-emerald-700 bg-emerald-50 border-emerald-200";
      case "TRAIN": return "text-indigo-700 bg-indigo-50 border-indigo-250";
      case "RICKSHAW": return "text-amber-750 bg-amber-50 border-amber-220";
      default: return "text-slate-600 bg-slate-50 border-slate-200";
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
        <History className="w-5 h-5 text-blue-600" />
        Commuter Travel Logs & Activity History
      </h2>

      {trips.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center text-slate-400 space-y-2 shadow-sm font-sans">
          <Calendar className="w-8 h-8 text-blue-500 block mx-auto animate-pulse" />
          <p className="text-xs font-semibold text-slate-700">No commuter history records captured yet</p>
          <p className="text-xxs text-slate-450">Plan and purchase routes under Route Planner to write records.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {trips.map((trip) => {
            const isExpanded = expandedTripId === trip.id;
            const tripDate = new Date(trip.start_time).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
            const tripTime = new Date(trip.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

            return (
              <div 
                key={trip.id} 
                className="bg-white border border-slate-200 rounded-xl p-5 hover:border-slate-350 transition duration-200 shadow-sm font-sans"
              >
                {/* Header Summary Row */}
                <div 
                  className="flex flex-col md:flex-row md:items-center justify-between gap-4 cursor-pointer"
                  onClick={() => toggleExpand(trip.id)}
                >
                  <div className="space-y-1.5 flex-1 animate-fadeIn">
                    <div className="flex items-center gap-2 text-slate-400 text-[10px] font-mono uppercase tracking-wider">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>{tripDate} &middot; {tripTime}</span>
                      <span className="text-slate-300">&middot;</span>
                      <span className="text-[10px] font-bold text-slate-400 uppercase">ID: {trip.id.substring(0, 8).toUpperCase()}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-800 text-sm">{trip.source_address}</span>
                      <ArrowRight className="w-3.5 h-3.5 text-blue-600" />
                      <span className="font-bold text-slate-800 text-sm">{trip.destination_address}</span>
                    </div>
                  </div>

                  {/* Summary Metric Badges */}
                  <div className="flex flex-wrap items-center gap-3 md:gap-4.5 text-[11px] font-mono text-slate-550 font-semibold">
                    <div className="flex items-center gap-1">
                      <CreditCard className="w-3.5 h-3.5 text-blue-600" />
                      <span className="text-slate-800">₹{trip.total_fare}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-450" />
                      <span>{trip.total_duration_minutes} min</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-450" />
                      <span>{trip.total_distance_km} km</span>
                    </div>
                    <div className="flex items-center gap-1 text-emerald-700 font-bold bg-emerald-50 border border-emerald-150 px-2 py-1 rounded">
                      <Leaf className="w-3.5 h-3.5 text-emerald-605" />
                      <span>{trip.co2_saved_g}g CO2 saved</span>
                    </div>

                    <button 
                      className="p-1 hover:text-blue-600 cursor-pointer self-center"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleExpand(trip.id);
                      }}
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                    </button>
                  </div>
                </div>

                {/* Expanded leg segment details breakdown */}
                {isExpanded && trip.legs && (
                  <div className="mt-5 pt-4 border-t border-slate-150 space-y-4 animate-fadeIn">
                    <h4 className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold">Segmental details</h4>
                    
                    <div className="relative border-l border-slate-150 pl-4 ml-2 space-y-4">
                      {trip.legs.map((leg, idx) => (
                        <div key={leg.id || idx} className="relative space-y-0.5 text-xxs">
                          <span className="absolute -left-[20.5px] top-1.5 w-2 h-2 bg-white border border-blue-500 rounded-full" />
                          <div className="flex items-center gap-2 text-slate-500">
                            <span className={`px-1.5 py-0.5 border rounded text-[9px] uppercase font-bold tracking-wider font-mono ${getModeLabelColor(leg.transport_code)}`}>
                              {leg.transport_code}
                            </span>
                            <span className="font-mono text-[9px] text-slate-450">
                              {leg.distance_km} km &middot; {leg.duration_minutes} min &middot; ₹{leg.fare}
                            </span>
                          </div>
                          <p className="text-slate-650">
                            From <span className="font-semibold text-slate-800">{leg.source_name}</span> to <span className="font-semibold text-slate-800">{leg.destination_name}</span>
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
