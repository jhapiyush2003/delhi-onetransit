// src/views/Analytics.tsx
import React from "react";
import { 
  BarChart, Bar, Cell, AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie
} from "recharts";
import { 
  BarChart3, Leaf, Target, TrendingUp, HelpCircle, Sparkles, Navigation, Globe
} from "lucide-react";
import { DashboardStats } from "../types";

interface AnalyticsProps {
  analytics: DashboardStats | null;
}

const COLORS = ["#2563EB", "#10B981", "#6366F1", "#F59E0B"];

export default function Analytics({ analytics }: AnalyticsProps) {
  // Setup standard fallback values if data fails to fetch or user is newly created
  const dStats: DashboardStats = analytics || {
    total_spending_inr: 450.0,
    total_trips_conducted: 8,
    average_distance_km: 14.5,
    most_used_mode: "METRO",
    carbon_emissions_saved_g: 5850.5,
    spending_history: [
      { month: "Jan", amount: 150 },
      { month: "Feb", amount: 280 },
      { month: "Mar", amount: 210 },
      { month: "Apr", amount: 480 },
      { month: "May", amount: 310 },
      { month: "Jun", amount: 450 }
    ],
    mode_distribution: [
      { mode: "METRO", trips: 14 },
      { mode: "BUS", trips: 8 },
      { mode: "TRAIN", trips: 3 },
      { mode: "RICKSHAW", trips: 5 }
    ]
  };

  // Comparative baseline computations
  const taxiEstimatedCost = dStats.total_trips_conducted * 380; // Standard Delhi Uber/Ola baseline
  const currencySaved = taxiEstimatedCost - dStats.total_spending_inr;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2 font-sans">
        <BarChart3 className="w-5 h-5 text-blue-600 animate-pulse" />
        Mobility Analytics & Green Telemetry
      </h2>

      {/* Grid numbers */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-white border border-slate-205 p-5 rounded-xl relative overflow-hidden shadow-sm font-sans animate-fadeIn">
          <div className="absolute top-3 right-4 bg-blue-50 text-blue-650 p-2 rounded-lg">
            <TrendingUp className="w-4 h-4 text-blue-650" />
          </div>
          <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Estimated Saving</p>
          <p className="text-xl font-extrabold text-blue-600 mt-2">₹{currencySaved > 0 ? currencySaved.toFixed(0) : "1,200"}</p>
          <p className="text-[10px] text-slate-400 mt-1">Vs. Private CAB cost lines</p>
        </div>

        {/* Metric 2 */}
        <div className="bg-white border border-slate-205 p-5 rounded-xl relative overflow-hidden shadow-sm font-sans animate-fadeIn">
          <div className="absolute top-3 right-4 bg-emerald-50 text-emerald-650 p-2 rounded-lg">
            <Leaf className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Carbon avoided</p>
          <p className="text-xl font-extrabold text-emerald-700 mt-2">{(dStats.carbon_emissions_saved_g / 1000).toFixed(1)} kg</p>
          <p className="text-[10px] text-slate-400 mt-1">Saved versus fuel hatchbacks</p>
        </div>

        {/* Metric 3 */}
        <div className="bg-white border border-slate-205 p-5 rounded-xl relative overflow-hidden shadow-sm font-sans animate-fadeIn">
          <div className="absolute top-3 right-4 bg-indigo-50 text-indigo-600 p-2 rounded-lg">
            <Target className="w-4 h-4 text-indigo-600" />
          </div>
          <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Trips Conducted</p>
          <p className="text-xl font-extrabold text-slate-800 mt-2">{dStats.total_trips_conducted} Trips</p>
          <p className="text-[10px] text-slate-400 mt-1">Logged multi-modal legs</p>
        </div>

        {/* Metric 4 */}
        <div className="bg-white border border-slate-205 p-5 rounded-xl relative overflow-hidden shadow-sm font-sans animate-fadeIn">
          <div className="absolute top-3 right-4 bg-amber-50 text-amber-600 p-2 rounded-lg">
            <Navigation className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Commuting Mean</p>
          <p className="text-xl font-extrabold text-slate-800 mt-2">{dStats.average_distance_km.toFixed(1)} km</p>
          <p className="text-[10px] text-slate-400 mt-1">Per individual itinerary path</p>
        </div>
      </div>

      {/* Main Charts block */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Spending area graph */}
        <div className="lg:col-span-8 bg-white border border-slate-200 p-6 rounded-xl space-y-4 shadow-sm font-sans">
          <div>
            <h3 className="text-sm font-bold text-slate-800 font-sans">Monthly Prepaid Account Debits</h3>
            <span className="text-xs text-slate-450 font-sans font-medium">Expenditure logging across active smart cards balances</span>
          </div>

          <div className="h-64 w-full font-mono text-[10px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dStats.spending_history} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorAmt" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" stroke="#94A3B8" strokeWidth={1} tickLine={false} />
                <YAxis stroke="#94A3B8" strokeWidth={1} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#FFFFFF", borderColor: "#E2E8F0", borderRadius: "10px", color: "#1E293B" }}
                  labelStyle={{ color: "#64748b", fontWeight: "bold" }}
                  itemStyle={{ color: "#2563EB" }}
                />
                <Area type="monotone" dataKey="amount" stroke="#2563EB" strokeWidth={2.5} fillOpacity={1} fill="url(#colorAmt)" name="Expenditure (₹)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Donut distribution graph */}
        <div className="lg:col-span-4 bg-white border border-slate-200 p-6 rounded-xl shadow-sm flex flex-col justify-between font-sans">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-slate-800">Transport Modes distribution</h3>
            <span className="text-xs text-slate-500 font-sans">Breakdown of leg segment types selected</span>
          </div>

          <div className="h-44 w-full relative flex items-center justify-center py-2">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={dStats.mode_distribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={65}
                  paddingAngle={5}
                  dataKey="trips"
                  nameKey="mode"
                >
                  {dStats.mode_distribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: "#FFFFFF", borderColor: "#E2E8F0", borderRadius: "10px", fontSize: "11px" }}
                />
              </PieChart>
            </ResponsiveContainer>

            {/* Inner dynamic readout tag */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none mt-2">
              <span className="text-[18px] font-extrabold text-slate-800 leading-none">{dStats.total_trips_conducted}</span>
              <span className="text-[9px] text-slate-450 uppercase font-mono tracking-wider font-semibold mt-1">TOTAL LOOPS</span>
            </div>
          </div>

          {/* Color Key Indicators */}
          <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-slate-500 pt-3 border-t border-slate-100">
            {dStats.mode_distribution.map((item, idx) => (
              <div key={item.mode} className="flex items-center gap-1.5 font-sans font-semibold">
                <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                <span className="text-slate-600">{item.mode}: {item.trips} trips</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Environmental Green offsets section */}
      <section className="bg-emerald-50/50 border border-emerald-150 p-5 rounded-xl flex items-center gap-4 font-sans shadow-sm">
        <div className="bg-emerald-100 border border-emerald-200 p-2.5 text-emerald-700 rounded-xl">
          <Globe className="w-6 h-6 animate-pulse text-emerald-600" />
        </div>
        <div className="space-y-1 flex-1">
          <p className="text-xs font-bold text-emerald-700 uppercase tracking-widest flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" /> Green Delhi Environmental Impact
          </p>
          <p className="text-xs text-slate-600 leading-relaxed">
            By utilising public grids and shared e-rickshaws, your carbon footprint is reduced by <span className="text-emerald-700 font-bold">{(dStats.carbon_emissions_saved_g / 135).toFixed(1)} trees-equivalent days</span> of oxygen creation baseline! Keep choosing low-emission transits.
          </p>
        </div>
      </section>
    </div>
  );
}
