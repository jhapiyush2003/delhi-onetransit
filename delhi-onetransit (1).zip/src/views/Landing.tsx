// src/views/Landing.tsx
import React, { useState } from "react";
import { Train, Search, ArrowRight, ShieldCheck, Leaf, Sparkles } from "lucide-react";

interface LandingProps {
  setView: (view: string) => void;
  onQuickSearch: (src: string, dst: string) => void;
}

export default function Landing({ setView, onQuickSearch }: LandingProps) {
  const [src, setSrc] = useState("Rajiv Chowk");
  const [dst, setDst] = useState("GTB Nagar");

  const handleSearchClick = (e: React.FormEvent) => {
    e.preventDefault();
    if (src === dst) {
      alert("Origin and destination cannot match!");
      return;
    }
    onQuickSearch(src, dst);
  };

  const sampleNodes = [
    "Rajiv Chowk", "Kashmere Gate", "GTB Nagar", "HUDA City Centre",
    "Noida Sector 62", "Hazrat Nizamuddin", "New Delhi Station", "Anand Vihar"
  ];

  return (
    <div className="bg-slate-50 text-slate-800 min-h-screen flex flex-col justify-between relative overflow-hidden font-sans">
      {/* Dynamic Grid Background Layer */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(37,99,235,0.07),transparent_50%50%)] z-0" />
      <div className="absolute inset-0 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:24px_24px] opacity-60 z-0" />

      {/* Header Bar */}
      <header className="relative z-10 border-b border-slate-200 bg-white/70 backdrop-blur-md px-6 py-4 flex items-center justify-between max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-2.5">
          <div className="bg-blue-50 border border-blue-100 p-1.5 rounded-lg">
            <Train className="w-5 h-5 text-blue-600" />
          </div>
          <span className="font-bold tracking-tight text-md text-slate-800">OneTransit</span>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => setView("login")}
            id="landing-login-btn"
            className="text-sm font-semibold hover:text-blue-600 text-slate-600 transition px-3 cursor-pointer"
          >
            Sign In
          </button>
          <button
            onClick={() => setView("signup")}
            id="landing-signup-btn"
            className="text-xs font-bold bg-blue-600 text-white px-4.5 py-2.5 rounded-lg hover:bg-blue-700 transition shadow-sm cursor-pointer"
          >
            Create Account
          </button>
        </div>
      </header>

      {/* Hero Body */}
      <main className="relative z-10 max-w-6xl mx-auto px-6 py-12 md:py-20 w-full grid grid-cols-1 md:grid-cols-12 gap-10 items-center">
        {/* Left copy column */}
        <section className="md:col-span-6 space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 border border-blue-100 rounded-full text-[11px] font-semibold text-blue-700 tracking-wide uppercase leading-none">
            <Sparkles className="w-3.5 h-3.5 text-blue-600 animate-pulse" /> Live Showcase Trial
          </div>

          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-slate-900 leading-tight">
            Unified Transit for <br className="hidden md:inline" />
            <span className="bg-gradient-to-r from-blue-600 to-indigo-650 bg-clip-text text-transparent">
              Delhi NCR
            </span>
          </h1>

          <p className="text-sm md:text-base text-slate-600 leading-relaxed max-w-lg">
            Navigate the Capital flawlessly. OneTransit integrates the Delhi Metro, DTC Buses, Suburban EMU Trains, and regional E-Rickshaws inside a single high-fidelity routing and digital card ledger.
          </p>

          <footer className="grid grid-cols-3 gap-6 pt-6 border-t border-slate-200">
            <div>
              <p className="text-xl font-bold text-slate-900 leading-none">5 Modes</p>
              <p className="text-[10px] text-slate-400 font-mono mt-1 uppercase tracking-wider">Inter-Routed</p>
            </div>
            <div>
              <p className="text-xl font-bold text-blue-600 leading-none">Dijkstra</p>
              <p className="text-[10px] text-slate-400 font-mono mt-1 uppercase tracking-wider">A* Optimizer</p>
            </div>
            <div>
              <div className="flex items-center gap-1">
                <Leaf className="w-4 h-4 text-emerald-600" />
                <p className="text-xl font-bold text-emerald-600 leading-none">CO₂ Saved</p>
              </div>
              <p className="text-[10px] text-slate-400 font-mono mt-1 uppercase tracking-wider">Emissions Logged</p>
            </div>
          </footer>
        </section>

        {/* Right Search Input Box */}
        <section className="md:col-span-6 bg-white border border-slate-250/80 rounded-2xl p-6 md:p-8 shadow-md relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
          <h2 className="text-lg font-bold text-slate-800 mb-1">Try Guest Optimizer Route Search</h2>
          <p className="text-xs text-slate-550 mb-6 leading-relaxed">
            Search optimal pathways linking metro lines and feeders. Sign in afterwards to log travel history and recharge smart cards.
          </p>

          <form onSubmit={handleSearchClick} className="space-y-4">
            <div>
              <label className="block text-[11px] font-bold text-slate-450 uppercase tracking-wide mb-1.5">Origin Station or Hub</label>
              <select
                value={src}
                onChange={(e) => setSrc(e.target.value)}
                id="landing-search-src"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs text-slate-700 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              >
                {sampleNodes.map((n) => (
                  <option key={n} value={n}>{n}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-450 uppercase tracking-wide mb-1.5">Destination Station</label>
              <select
                value={dst}
                onChange={(e) => setDst(e.target.value)}
                id="landing-search-dst"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs text-slate-700 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              >
                {sampleNodes.map((n) => (
                  <option key={n} value={n}>{n}</option>
                ))}
              </select>
            </div>

            <button
              type="submit"
              id="landing-search-submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-sm"
            >
              <Search className="w-4 h-4 text-white" />
              Find Optimal Multi-Modal Pathway
              <ArrowRight className="w-4 h-4 text-white" />
            </button>
          </form>

          {/* Quick Trial Access Banner for Recruiter */}
          <div className="mt-6 pt-5 border-t border-slate-150 text-center">
            <span className="text-[10px] text-slate-400 font-mono tracking-wider uppercase block mb-2">RECRUITER BYPASS ENTRY</span>
            <button
              onClick={() => setView("login")}
              className="mt-1 w-full border border-blue-200 bg-blue-50/50 hover:bg-blue-50 text-blue-700 font-semibold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4 text-blue-600" />
              Bypass Login as Demo Admin / User
            </button>
          </div>
        </section>
      </main>

      {/* Footer Block */}
      <footer className="relative z-10 border-t border-slate-200 py-6 text-center text-slate-400 text-[11px] max-w-7xl mx-auto w-full">
        <p>&copy; {new Date().getFullYear()} OneTransit Platform NCR. Professional Enterprise Architecture.</p>
        <div className="mt-2 flex items-center justify-center gap-3 font-mono text-[10px]">
          <span className="hover:text-slate-600 cursor-pointer">Security Audited</span>
          <span>&middot;</span>
          <span className="hover:text-slate-600 cursor-pointer">Node.js Engine</span>
          <span>&middot;</span>
          <span className="hover:text-slate-600 cursor-pointer">PostgreSQL Drizzle</span>
        </div>
      </footer>
    </div>
  );
}
