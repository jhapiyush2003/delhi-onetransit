// src/views/Signup.tsx
import React, { useState } from "react";
import { Train, User, Mail, Lock, CheckCircle2, ArrowRight } from "lucide-react";

interface SignupProps {
  setView: (view: string) => void;
  onSignup: (name: string, email: string, pass: string) => Promise<boolean>;
}

export default function Signup({ setView, onSignup }: SignupProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorText, setErrorText] = useState("");
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password) {
      setErrorText("All parameters are required.");
      return;
    }
    setLoading(true);
    setErrorText("");

    try {
      const res = await onSignup(name, email, password);
      if (res) {
        setSuccess(true);
      } else {
        setErrorText("This email address is already registered.");
      }
    } catch (err: any) {
      setErrorText(err?.message || "Server gateway timed out.");
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="bg-slate-50 text-slate-800 min-h-screen flex items-center justify-center p-4 relative overflow-hidden font-sans">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(37,99,235,0.06),transparent_60%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:24px_24px] opacity-60 pointer-events-none" />

        <div className="relative z-10 w-full max-w-md bg-white border border-slate-200 rounded-2xl p-6 md:p-8 text-center space-y-6 shadow-md">
          <div className="inline-flex p-3 bg-emerald-50 border border-emerald-150 rounded-full text-emerald-600">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-bold text-slate-800 tracking-tight">Prepaid Account Activated!</h3>
            <p className="text-xs text-slate-550 leading-relaxed max-w-sm mx-auto">
              Welcome to OneTransit. Your profile has been loaded with an initial bonus of ₹350 in digital cash to test out route tickets!
            </p>
          </div>
          <button
            onClick={() => setView("login")}
            className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 hover:bg-blue-700 transition cursor-pointer shadow-sm"
          >
            Sign In with Active Credentials
            <ArrowRight className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 text-slate-800 min-h-screen flex items-center justify-center p-4 relative overflow-hidden font-sans">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(37,99,235,0.06),transparent_60%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:24px_24px] opacity-60 pointer-events-none" />

      <div className="relative z-10 w-full max-w-md bg-white border border-slate-200 rounded-2xl p-6 md:p-8 shadow-md space-y-6">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center bg-blue-600 p-2.5 rounded-xl text-white shadow-sm">
            <Train className="w-5 h-5 text-white" />
          </div>
          <h2 className="text-lg font-bold text-slate-800 tracking-tight">Creating Wallet Account</h2>
          <p className="text-xs text-slate-500">Sign up and receive an instantly loaded virtual smart card</p>
        </div>

        {errorText && (
          <div className="px-3 py-2.5 bg-red-50 border border-red-150 rounded-xl text-red-650 text-xs">
            {errorText}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-bold text-slate-450 uppercase tracking-wide mb-1.5 font-semibold">Your Full Name</label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                placeholder="John Doe"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-700 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-450 uppercase tracking-wide mb-1.5 font-semibold">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="email"
                placeholder="johndoe@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-700 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-450 uppercase tracking-wide mb-1.5 font-semibold">Secret Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-700 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 font-bold py-3.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-sm"
          >
            {loading ? "Activating Credentials..." : "Activate OneTransit Card"}
            <ArrowRight className="w-4 h-4 text-white" />
          </button>
        </form>

        <p className="text-xs text-center text-slate-500">
          Already have an account?{" "}
          <button onClick={() => setView("login")} className="text-blue-600 font-semibold hover:underline cursor-pointer">
            Sign In
          </button>
        </p>
      </div>
    </div>
  );
}
