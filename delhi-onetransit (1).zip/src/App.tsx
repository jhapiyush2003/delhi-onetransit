// src/App.tsx
import React, { useEffect, useState } from "react";
import Sidebar from "./components/Sidebar";
import Landing from "./views/Landing";
import Login from "./views/Login";
import Signup from "./views/Signup";
import Dashboard from "./views/Dashboard";
import RoutePlanner from "./views/RoutePlanner";
import WalletView from "./views/Wallet";
import TravelHistory from "./views/TravelHistory";
import Analytics from "./views/Analytics";
import ProfileView from "./views/Profile";
import AdminDashboard from "./views/AdminDashboard";

import { 
  User, Wallet, TransitPass, WalletTransaction, TravelTrip, DashboardStats, MultimodalRouteResponse, UserProfile 
} from "./types";

export default function App() {
  const [currentView, setCurrentView] = useState<string>("landing");
  const [authToken, setAuthToken] = useState<string | null>(localStorage.getItem("onTransit_token"));
  const [user, setUser] = useState<User | null>(null);

  // Hydrated wallet, transactions, passes, trip logs and metrics
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [activePasses, setActivePasses] = useState<TransitPass[]>([]);
  const [trips, setTrips] = useState<TravelTrip[]>([]);
  const [analytics, setAnalytics] = useState<DashboardStats | null>(null);

  // Store pre-guest query solved pathways directly
  const [guestRouteResult, setGuestRouteResult] = useState<MultimodalRouteResponse | null>(null);

  // Authenticated Headers Helper
  const getAuthHeaders = () => {
    return {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${authToken}`
    };
  };

  // Synchronize dynamic details from server
  const hydrateSessionData = async () => {
    if (!authToken) return;
    try {
      // 1. Fetch user Profile
      const profileRes = await fetch("/api/v1/auth/profile", {
        headers: getAuthHeaders()
      });
      if (profileRes.status === 401) {
        handleLogout();
        return;
      }
      if (profileRes.ok) {
        const uData: User = await profileRes.json();
        setUser(uData);
      }

      // 2. Fetch Wallet state and active Passes
      const walletRes = await fetch("/api/v1/wallet", {
        headers: getAuthHeaders()
      });
      if (walletRes.ok) {
        const wData = await walletRes.json();
        setWallet(wData.wallet);
        setTransactions(wData.transactions);
        setActivePasses(wData.active_passes);
      }

      // 3. Fetch historic commute Trips
      const historyRes = await fetch("/api/v1/history", {
        headers: getAuthHeaders()
      });
      if (historyRes.ok) {
        const tripsList = await historyRes.json();
        setTrips(tripsList);
      }

      // 4. Fetch Green offset Analytics metrics
      const analyticsRes = await fetch("/api/v1/history/analytics", {
        headers: getAuthHeaders()
      });
      if (analyticsRes.ok) {
        const aData = await analyticsRes.json();
        setAnalytics(aData);
      }
    } catch (err) {
      console.error("Master hydration failed:", err);
    }
  };

  useEffect(() => {
    if (authToken) {
      hydrateSessionData();
      if (currentView === "landing" || currentView === "login" || currentView === "signup") {
        setCurrentView("planner"); // Navigate directly inside
      }
    } else {
      setUser(null);
      if (currentView !== "landing" && currentView !== "signup") {
        setCurrentView("landing");
      }
    }
  }, [authToken]);

  const handleLogin = async (emailInput: string, passwordInput: string): Promise<boolean> => {
    try {
      const loginRes = await fetch("/api/v1/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: emailInput, password: passwordInput })
      });

      if (loginRes.ok) {
        const authData = await loginRes.json();
        const token = authData.access_token;
        localStorage.setItem("onTransit_token", token);
        setAuthToken(token);
        return true;
      }
      return false;
    } catch (err) {
      console.error("Gateway login issue:", err);
      return false;
    }
  };

  const handleSignup = async (nameInput: string, emailInput: string, passwordInput: string): Promise<boolean> => {
    try {
      const signupRes = await fetch("/api/v1/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ full_name: nameInput, email: emailInput, password: passwordInput })
      });
      return signupRes.ok;
    } catch (err) {
      console.error("Signup network registration failure:", err);
      return false;
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("onTransit_token");
    setAuthToken(null);
    setUser(null);
    setWallet(null);
    setTransactions([]);
    setActivePasses([]);
    setTrips([]);
    setAnalytics(null);
    setGuestRouteResult(null);
    setCurrentView("landing");
  };

  // Perform route query searches on graph database
  const handleQuerySearch = async (src: string, dst: string, priorityWeight: string): Promise<MultimodalRouteResponse | null> => {
    try {
      const searchRes = await fetch("/api/v1/router/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ source: src, destination: dst, priority: priorityWeight })
      });

      if (searchRes.ok) {
        const routeData = await searchRes.json();
        return routeData;
      }
      return null;
    } catch (err) {
      console.error("Route compilation failure:", err);
      return null;
    }
  };

  const handleSaveJourney = async (tripInput: Omit<TravelTrip, "id">): Promise<boolean> => {
    try {
      const saveRes = await fetch("/api/v1/history/log_trip", {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify(tripInput)
      });
      if (saveRes.ok) {
        await hydrateSessionData(); // Refresh wallet and analytics instantly
        return true;
      }
      return false;
    } catch (err) {
      console.error("Itinerary log failed:", err);
      return false;
    }
  };

  const handleRechargeWallet = async (amountInput: number, methodInput: string): Promise<boolean> => {
    try {
      const rechargeRes = await fetch("/api/v1/wallet/recharge", {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ amount: amountInput, payment_method: methodInput })
      });
      if (rechargeRes.ok) {
        await hydrateSessionData();
        return true;
      }
      return false;
    } catch (err) {
      console.error("Wallet topup failed:", err);
      return false;
    }
  };

  const handleBuyPass = async (passTypeInput: string, modeInput: string, priceInput: number): Promise<boolean> => {
    try {
      const buyPassRes = await fetch("/api/v1/wallet/purchase_pass", {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ pass_type: passTypeInput, transport_mode: modeInput, price: priceInput })
      });
      if (buyPassRes.ok) {
        await hydrateSessionData();
        return true;
      }
      return false;
    } catch (err) {
      console.error("Sub purchase transaction failed:", err);
      return false;
    }
  };

  const handleUpdateProfile = async (profileInput: UserProfile): Promise<boolean> => {
    try {
      const updateRes = await fetch("/api/v1/auth/profile", {
        method: "PUT",
        headers: getAuthHeaders(),
        body: JSON.stringify(profileInput)
      });
      if (updateRes.ok) {
        await hydrateSessionData();
        return true;
      }
      return false;
    } catch (err) {
      console.error("Profile synchronization issues:", err);
      return false;
    }
  };

  // Administrative retrieval callbacks
  const handleAdminFetchUsers = async (): Promise<User[]> => {
    const res = await fetch("/api/v1/admin/users", { headers: getAuthHeaders() });
    return res.ok ? await res.json() : [];
  };

  const handleAdminFetchTransactions = async (): Promise<WalletTransaction[]> => {
    const res = await fetch("/api/v1/admin/transactions", { headers: getAuthHeaders() });
    return res.ok ? await res.json() : [];
  };

  // Launch direct routing search from guest Landing View
  const handleGuestQuickSearch = async (src: string, dst: string) => {
    const resultSolved = await handleQuerySearch(src, dst, "fastest");
    if (resultSolved) {
      setGuestRouteResult(resultSolved);
      setCurrentView("planner"); // Instantly shift view
    } else {
      alert("Failed to compile guest routes.");
    }
  };

  return (
    <div className="bg-slate-950 min-h-screen text-slate-100 flex flex-col md:flex-row antialiased selection:bg-teal-500/30 selection:text-teal-200">
      
      {!authToken ? (
        // Visitor/Registration Frame View
        <div className="w-full flex-1 min-h-screen">
          {currentView === "landing" && (
            <Landing setView={setCurrentView} onQuickSearch={handleGuestQuickSearch} />
          )}
          {currentView === "login" && (
            <Login setView={setCurrentView} onLogin={handleLogin} />
          )}
          {currentView === "signup" && (
            <Signup setView={setCurrentView} onSignup={handleSignup} />
          )}
        </div>
      ) : (
        // Authenticated Passenger Hub SaaS frame
        <>
          <Sidebar currentView={currentView} setView={setCurrentView} user={user} onLogout={handleLogout} />
          
          <main className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6 max-w-7xl mx-auto w-full h-screen">
            {currentView === "planner" && (
              <RoutePlanner 
                user={user!} 
                wallet={wallet} 
                onSearch={handleQuerySearch} 
                onSaveTrip={handleSaveJourney} 
                setView={setCurrentView}
                guestRouteResult={guestRouteResult}
              />
            )}
            {currentView === "wallet" && (
              <WalletView 
                user={user!} 
                wallet={wallet} 
                transactions={transactions} 
                activePasses={activePasses} 
                onRecharge={handleRechargeWallet} 
                onBuyPass={handleBuyPass}
              />
            )}
            {currentView === "history" && (
              <TravelHistory trips={trips} />
            )}
            {currentView === "analytics" && (
              <Analytics analytics={analytics} />
            )}
            {currentView === "profile" && (
              <ProfileView user={user!} onUpdateProfile={handleUpdateProfile} />
            )}
            {currentView === "admin" && user?.role === "Admin" && (
              <AdminDashboard 
                adminUser={user!} 
                onFetchUsers={handleAdminFetchUsers} 
                onFetchTransactions={handleAdminFetchTransactions} 
              />
            )}
          </main>
        </>
      )}
    </div>
  );
}
export {}
