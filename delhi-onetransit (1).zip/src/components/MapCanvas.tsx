// src/components/MapCanvas.tsx
import React from "react";
import { TravelTripLeg } from "../types";

interface MapCanvasProps {
  highlightLegs?: TravelTripLeg[];
}

// Fixed dimensions for Delhi relative canvas mapping
const WIDTH = 500;
const HEIGHT = 400;

// Nodes positions coordinate mapping optimized for 500x400 canvas display
const MAP_COORDS: Record<string, { x: number; y: number; col: string }> = {
  "Rajiv Chowk": { x: 250, y: 190, col: "#FF6B6B" }, // Central point
  "Kashmere Gate": { x: 260, y: 120, col: "#4DABF7" }, // North Hub
  "GTB Nagar": { x: 245, y: 60, col: "#FFD43B" }, // North Far
  "HUDA City Centre": { x: 120, y: 340, col: "#51CF66" }, // South-West Far (Gurugram)
  "Noida Sector 62": { x: 420, y: 200, col: "#94D82D" }, // East Far (Noida)
  "Hazrat Nizamuddin": { x: 310, y: 250, col: "#FCC419" }, // South-East (Train)
  "New Delhi Station": { x: 248, y: 160, col: "#845EF7" }, // Just Above Center
  "Vasant Kunj Sector C": { x: 170, y: 270, col: "#FA5252" }, // South-West (Residential)
  "Anand Vihar": { x: 380, y: 140, col: "#E64980" }, // Eastern Central Hub
  "Connaught Place Block A": { x: 260, y: 200, col: "#22B8CF" }, // cp feeder closeby
  "Delhi University Gate": { x: 235, y: 75, col: "#AE3EC9" }, // gtb closeby
};

export default function MapCanvas({ highlightLegs = [] }: MapCanvasProps) {
  // Determine nodes that are targeted in active directions
  const activeNodes = new Set<string>();
  highlightLegs.forEach((leg) => {
    activeNodes.add(leg.source_name);
    activeNodes.add(leg.destination_name);
  });

  return (
    <div className="bg-slate-950 border border-slate-850 rounded-2xl p-4 overflow-hidden relative md:shadow-inner flex flex-col items-center">
      <div className="absolute top-3 left-4 text-[10px] text-slate-400 font-mono tracking-wider uppercase bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
        Live Delhi NCR Multi-Modal Mapping Web
      </div>

      <svg viewBox={`0 0 ${WIDTH} ${HEIGHT}`} className="w-full max-w-full h-auto aspect-[5/4] transition-all">
        {/* Background Network Guides */}
        {/* Yellow Transit Line vector */}
        <polyline
          points="245,60 260,120 248,160 250,190 120,340"
          fill="none"
          stroke="#EFD314"
          strokeWidth="3.5"
          strokeOpacity="0.30"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Blue Transit Line vector */}
        <polyline
          points="250,190 380,140 420,200"
          fill="none"
          stroke="#0F79EF"
          strokeWidth="3.5"
          strokeOpacity="0.30"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* DTC Bus Route Lines */}
        <line x1="245" y1="60" x2="260" y2="120" stroke="#10B981" strokeWidth="2" strokeDasharray="3,3" strokeOpacity="0.4" />
        <line x1="260" y1="120" x2="310" y2="250" stroke="#10B981" strokeWidth="2" strokeDasharray="3,3" strokeOpacity="0.4" />
        <line x1="170" y1="270" x2="250" y2="190" stroke="#10B981" strokeWidth="2" strokeDasharray="3,3" strokeOpacity="0.4" />

        {/* suburban rail railway path */}
        <polyline
          points="310,250 248,160 380,140"
          fill="none"
          stroke="#E2E8F0"
          strokeWidth="2.5"
          strokeOpacity="0.2"
          strokeLinecap="round"
        />

        {/* Pulsing Active Paths highlights representation */}
        {highlightLegs.map((leg, idx) => {
          const ptA = MAP_COORDS[leg.source_name];
          const ptB = MAP_COORDS[leg.destination_name];
          if (!ptA || !ptB) return null;

          // Select glowing accent color
          let col = "#E2E8F0"; // WALK default gray
          if (leg.transport_code === "METRO") col = "#14B8A6"; // Teal energy path
          if (leg.transport_code === "BUS") col = "#10B981"; // Green bus path
          if (leg.transport_code === "TRAIN") col = "#6366F1"; // Indigo express rail path
          if (leg.transport_code === "RICKSHAW") col = "#EAB308"; // Amber rickshaw loop

          return (
            <g key={idx}>
              <line
                x1={ptA.x}
                y1={ptA.y}
                x2={ptB.x}
                y2={ptB.y}
                stroke={col}
                strokeWidth="5"
                strokeLinecap="round"
                className="animate-pulse"
              />
              {/* Arrow trajectory point */}
              <circle cx={ptB.x} cy={ptB.y} r="3.5" fill="#FFFFFF" />
            </g>
          );
        })}

        {/* Drawing Local Stations Nodes */}
        {Object.entries(MAP_COORDS).map(([name, pt]) => {
          const isActive = activeNodes.has(name);
          return (
            <g key={name} className="group cursor-pointer">
              {isActive ? (
                // Pulse halo ring mapping
                <circle cx={pt.x} cy={pt.y} r="10" fill={pt.col} fillOpacity="0.28" className="animate-ping" />
              ) : null}

              <circle
                cx={pt.x}
                cy={pt.y}
                r={isActive ? "7" : "5.5"}
                fill={isActive ? "#0E1729" : pt.col}
                stroke={isActive ? pt.col : "#1E293B"}
                strokeWidth={isActive ? "2.5" : "1.5"}
                className="transition-all duration-300 hover:scale-130"
              />

              {/* Station Titles labels */}
              <text
                x={pt.x}
                y={pt.y - 10}
                textAnchor="middle"
                fill={isActive ? "#38BDF8" : "#94A3B8"}
                fontSize={isActive ? "9.5" : "8"}
                fontFamily="sans-serif"
                fontWeight={isActive ? "bold" : "normal"}
                className="pointer-events-none drop-shadow-[0_1px_1px_rgba(0,0,0,0.85)] group-hover:fill-sky-300"
              >
                {name}
              </text>
            </g>
          );
        })}
      </svg>

      {/* Legend Block */}
      <div className="mt-2.5 flex flex-wrap gap-x-4 gap-y-2 justify-center text-[10px] text-slate-400 font-mono">
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-1 bg-[#EFD314] rounded-full inline-block" />
          <span>Metro Yellow</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-1 bg-[#0F79EF] rounded-full inline-block" />
          <span>Metro Blue</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-1 bg-[#10B981] rounded-full inline-block" />
          <span>DTC Bus Route</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-1 bg-slate-100 rounded-full inline-block" />
          <span>Train Rails</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-1 bg-orange-400 rounded-full inline-block animate-pulse" />
          <span>Active Journey</span>
        </div>
      </div>
    </div>
  );
}
