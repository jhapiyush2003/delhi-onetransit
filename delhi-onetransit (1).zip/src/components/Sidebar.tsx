// src/components/Sidebar.tsx
import React from "react";
import { 
  MapPin, Wallet, History, BarChart3, User, ShieldCheck, LogOut, Navigation, Menu, X, Train
} from "lucide-react";
import { User as UserType } from "../types";

interface SidebarProps {
  currentView: string;
  setView: (view: string) => void;
  user: UserType | null;
  onLogout: () => void;
}

export default function Sidebar({ currentView, setView, user, onLogout }: SidebarProps) {
  const [isOpen, setIsOpen] = React.useState(false);

  const menuItems = [
    { id: "planner", label: "Route Planner", icon: MapPin },
    { id: "wallet", label: "Smart Wallet", icon: Wallet },
    { id: "history", label: "Travel History", icon: History },
    { id: "analytics", label: "Analytics Dashboard", icon: BarChart3 },
    { id: "profile", label: "Profile Settings", icon: User },
  ];

  if (user?.role === "Admin") {
    menuItems.push({ id: "admin", label: "Admin Console", icon: ShieldCheck });
  }

  const handleNav = (vId: string) => {
    setView(vId);
    setIsOpen(false);
  };

  return (
    <>
      {/* Mobile Toggle Button */}
      <div className="md:hidden flex items-center justify-between p-4 bg-white border-b border-slate-200 sticky top-0 z-40 text-slate-800 shadow-sm font-sans">
        <div className="flex items-center gap-2 font-black tracking-tight text-blue-600 text-sm">
          <Train className="w-5 h-5 text-blue-600" />
          ONETRANSIT
        </div>
        <button onClick={() => setIsOpen(!isOpen)} className="p-1.5 rounded-lg hover:bg-slate-100 transition text-slate-600" id="sidebar-toggle">
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Backdrop for open drawer on mobile */}
      {isOpen && (
        <div className="fixed inset-0 bg-slate-900/40 md:hidden z-30 transition-opacity" onClick={() => setIsOpen(false)} />
      )}

      {/* Main Drawer Container */}
      <aside className={`
        fixed top-0 bottom-0 left-0 bg-slate-50 border-r border-slate-200 text-slate-700 w-64 z-30 md:sticky
        transition-transform duration-300 transform md:transform-none h-screen flex flex-col justify-between font-sans shadow-sm
        ${isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}
      `}>
        <div>
          {/* Logo Brand Header */}
          <div className="p-6 border-b border-slate-200 flex items-center gap-3">
            <div className="h-8 w-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-sm">
              <Train className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-slate-800 font-extrabold text-lg tracking-tight leading-none">OneTransit</h1>
              <p className="text-[10px] text-slate-455 font-mono tracking-widest uppercase font-semibold mt-1">Delhi Commute Hub</p>
            </div>
          </div>

          {/* User brief widget */}
          {user && (
            <div className="p-4 mx-4 my-4 bg-white border border-slate-200 rounded-xl flex items-center gap-3 shadow-sm">
              <div className="w-10 h-10 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-blue-600 uppercase text-sm">
                {user.full_name.charAt(0)}
              </div>
              <div className="overflow-hidden">
                <p className="text-sm font-bold text-slate-800 truncate">{user.full_name}</p>
                <span className={`inline-block px-2.5 py-0.5 mt-1 text-[9px] font-bold rounded tracking-wider uppercase border ${
                  user.role === "Admin" ? "bg-red-50 text-red-705 border-red-150" : "bg-blue-50 text-blue-705 border-blue-150"
                }`}>
                  {user.role === "Admin" ? "Administrator" : "Passenger"}
                </span>
              </div>
            </div>
          )}

          {/* Nav Items */}
          <nav className="px-3 py-2 space-y-1">
            {menuItems.map((item) => {
              const IconComp = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  id={`nav-${item.id}`}
                  className={`
                    w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-bold transition-all duration-150 cursor-pointer
                    ${isActive 
                      ? "bg-blue-50 text-blue-700 border-l-4 border-blue-650 pl-2 shadow-sm" 
                      : "text-slate-650 hover:bg-slate-100 hover:text-slate-850"
                    }
                  `}
                >
                  <IconComp className={`w-5 h-5 ${isActive ? "text-blue-650" : "text-slate-450"}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer actions block */}
        <div className="p-4 border-t border-slate-205">
          <button
            onClick={onLogout}
            id="nav-logout"
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-bold text-slate-500 hover:bg-slate-105 hover:text-red-700 transition cursor-pointer"
          >
            <LogOut className="w-5 h-5 text-slate-400 hover:text-red-650" />
            Sign Out
          </button>
          <div className="mt-4 text-[10px] text-center font-mono tracking-wider text-slate-400 font-semibold uppercase">
            v1.3.0 (Recruiter Core)
          </div>
        </div>
      </aside>
    </>
  );
}
