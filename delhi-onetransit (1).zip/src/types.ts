// src/types.ts

export interface UserProfile {
  phone_number: string;
  preferred_language: string;
  home_latitude: string;
  home_longitude: string;
  work_latitude: string;
  work_longitude: string;
}

export interface Wallet {
  id: string;
  balance: number;
  status: string;
  updated_at: string;
}

export interface WalletTransaction {
  id: string;
  amount: number;
  transaction_type: "credit" | "debit" | "refund";
  description: string;
  reference_id: string;
  status: string;
  created_at: string;
  user_email?: string; // Admin reference
  user_name?: string;
}

export interface TransitPass {
  id: string;
  pass_type: string;
  transport_mode: string;
  price: number;
  starts_at: string;
  expires_at: string;
  is_active: boolean;
}

export interface TravelTripLeg {
  id?: string;
  transport_code: "METRO" | "BUS" | "TRAIN" | "RICKSHAW" | "WALK";
  source_name: string;
  destination_name: string;
  fare: number;
  distance_km: number;
  duration_minutes: number;
  line_name?: string;
  route_code?: string;
}

export interface TravelTrip {
  id: string;
  source_address: string;
  destination_address: string;
  total_fare: number;
  total_distance_km: number;
  total_duration_minutes: number;
  co2_saved_g: number;
  start_time: string;
  end_time: string;
  legs: TravelTripLeg[];
}

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: "User" | "Admin";
  status: "active" | "suspended";
  is_verified: boolean;
  created_at: string;
  profile?: UserProfile;
}

export interface DashboardStats {
  total_spending_inr: number;
  total_trips_conducted: number;
  average_distance_km: number;
  most_used_mode: string;
  carbon_emissions_saved_g: number;
  peak_travel_time_hour: string;
  spending_history: { month: string; amount: number }[];
  mode_distribution: { mode: string; trips: number }[];
}

export interface RouteLeg {
  transport_mode: "METRO" | "BUS" | "TRAIN" | "RICKSHAW" | "WALK";
  source_name: string;
  destination_name: string;
  distance_km: number;
  duration_minutes: number;
  fare: number;
  line_name?: string | null;
  route_code?: string | null;
}

export interface MultimodalRouteResponse {
  route_id: string;
  legs: RouteLeg[];
  total_fare: number;
  total_distance_km: number;
  total_duration_minutes: number;
  carbon_saved_g: number;
  number_of_interchanges: number;
}
