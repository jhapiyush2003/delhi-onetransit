# Delhi OneTransit — Relational Database Design

This document details the schema of **Delhi OneTransit**, consisting of exactly **25 normalized PostgreSQL tables (3NF)**. It covers user security, transit networks, fare models, wallets, passes, and travel logs.

---

## 1. Entity-Relationship (ER) Topography

```text
  [ user_login_logs ] ── (audit) ──┐
                                   ▼
  [ user_passwords ]  <── (1:1) ─ [ users ] ─── (1:1) ──> [ user_profiles ]
  [ refresh_tokens ] <── (1:N) ──┘   │
                                     ├─ (1:1) ─> [ wallets ] ─ (1:N) ─> [ wallet_transactions ]
                                     │
                                     ├─ (1:N) ─> [ transit_passes ]
                                     │
                                     └─ (1:N) ─> [ travel_trips ] 
                                                      │
                                                      └─ (1:N) ─> [ travel_trip_legs ]
                                                                        │
                                                                 (Associated with)
                                                                        ▼
                                                             [ transport_modes ] <── [ transit_agencies ]
                                                                        │
                                         ┌──────────────────────────────┼──────────────────────────────┐
                                         ▼                              ▼                              ▼
                                 (Delhi Metro)                      (DTC Bus)                     (EMU Train)
                                 [ metro_lines ]                 [ bus_routes ]                 [ train_routes ]
                                        │                              │                              │
                            [ metro_line_stations ]           [ bus_route_stops ]            [ train_stations ]
                                        │                              │                              │
                               [ metro_stations ]                [ bus_stops ]                [ train_fare_slabs ]
                                        │
                                 [ metro_fares ]
                                        
                                        ▼ (Flexible Feeder)
                                 [ erickshaw_zones ] <── (1:N) ── [ erickshaw_operators ]
```

---

## 2. Table Catalog (25 Tables)

### Module 1: Users, Authentication & Profiles
1. **`users`**
   - Core identifiers (UUID), email (unique), full name, registration flags, role structure (User/Admin), status (active, suspended).
2. **`user_passwords`**
   - Hashed credentials using Argon2/BCrypt, login fail counters, password lockers, and resetting secrets.
3. **`user_refresh_tokens`**
   - Persistent login tokens, device meta signatures, token rotation IDs, and strict expiration times.
4. **`user_profiles`**
   - Custom parameters like phone, language, common office (work) and home coordinates for autocomplete routing.
5. **`user_login_logs`**
   - Comprehensive security logs recording IP addresses, geographic location details, and success headers.

### Module 2: System-Wide General Transit Parameters
6. **`transport_modes`**
   - System standard codes (`METRO`, `BUS`, `TRAIN`, `RICKSHAW`, `WALK`) and fixed CO2 emissions (g/km) to calculate environment impact.
7. **`transit_agencies`**
   - Managing organizations (DMRC, DTC, NR, CP-RICKSHAW-ASSOC) holding support contact information and regulatory flags.

### Module 3: Delhi Metro Network (DMRC)
8. **`metro_lines`**
   - All lines (Yellow, Blue, Red, Magenta, Pink, Violet, Airport Express) and branding colors used by UI.
9. **`metro_stations`**
   - Complete station list (e.g., Rajiv Chowk, Kashmere Gate), precise coordinates, disabled facilities, and parking.
10. **`metro_line_stations`**
    - Ordered junctions indicating line alignments, allowing quick graph traversals across transfer hubs.
11. **`metro_fares`**
    - Grid pricing model for metro stations based on distance metrics and smartcard discount tiers.

### Module 4: Delhi Transport Corporation (DTC) Bus Network
12. **`bus_routes`**
    - Standard routes (e.g., 502, 419, 727, Outer Ring Road Specials), express flags, scheduling frequencies, directions.
13. **`bus_stops`**
    - Physical passenger stops, GIS coordinates, shelter indicators, and bus display terminals.
14. **`bus_route_stops`**
    - Linking routes directly to their constituent stops with standard sequence numbers (Stop 1 to Stop N).
15. **`bus_timings`**
    - Temporal schedules outlining dispatch times, peak frequencies, and seasonal operations.

### Module 5: Suburban Railways (EMU)
16. **`train_stations`**
    - Stations on commuter circuits (e.g., New Delhi, Nizamuddin, Anand Vihar, Ghaziabad, Gurgaon).
17. **`train_routes`**
    - Daily Suburban commuter routes connecting Outer NCR sectors.
18. **`train_fare_slabs`**
    - Distance-based pricing structures for EMU travel classes (Passes, General, First Class).

### Module 6: Feeder Services (E-Rickshaw)
19. **`erickshaw_zones`**
    - Dynamic catchment areas surrounding major metro exits and academic coordinates.
20. **`erickshaw_operators`**
    - Registered, screen-passed operators carrying physical validation credentials for security.

### Module 7: Unified Smart Wallet & Travel Passes
21. **`wallets`**
    - Virtual prepaid balance lockers linked to unique users, locked status configurations, and PIN hashes.
22. **`wallet_transactions`**
    - Double-entry recording of credits, routing charges, pass acquisitions, and instant refunds.
23. **`transit_passes`**
    - Digital passes (e.g., DTC Monthly AC Bus Pass, Delhi Metro Tourist Pass) tracking active durations.

### Module 8: Multi-Modal Intelligent Travel Journals
24. **`travel_trips`**
    - Fully consolidated consumer rides, mapping exact overall costs, distance traveled, transit durations, and carbon numbers.
25. **`travel_trip_legs`**
    - Specific travel segments that form a multimodal trip. Allows showing segmented route breakdowns like:
      - Leg 1: CP to Rajiv Chowk Metro (Walk - 400m)
      - Leg 2: Rajiv Chowk to Kashmere Gate (Metro - 8.2km)
      - Leg 3: Kashmere Gate to Civil Lines (DTC Bus 502 - 1.8km)

---

## 3. Database Integrity & Performance Strategies

### Primary-Key Strategy
UUIDv4 is utilized across all user-focused Tables (e.g., `users`, `wallets`, `transactions`, `trips`) to discourage crawling attacks. Integer sequences are safely utilized for static lookup lists (`transport_modes`, `metro_stations`) to speed up join operations.

### Indices & Optimization
- **B-Trees** configured on lookup columns frequently targeted by search criteria:
  - `users.email`
  - `wallet_transactions.wallet_id`
  - `travel_trips.user_id`
  - `metro_stations.name`
- **GIS Spatials / Multi-Columns**: Combined coordinate lookup indices facilitate rapid coordinate-distance calculations for feeder pick-ups.

### Database Constraints
- **Foreign Keys:** `ON DELETE CASCADE` applied cautiously. For core records like transactions or travel history, a `SET NULL` or soft-delete constraint prevents transactional record loss.
- **Value Limits Check Constraints (`CHECK`):**
  - `wallet_transactions.amount > 0`
  - `wallets.balance >= 0` (strict overdraft avoidance)
  - `users.role IN ('User', 'Admin')`
  - `travel_trips.duration > 0`
