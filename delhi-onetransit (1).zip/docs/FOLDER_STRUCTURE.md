# Delhi OneTransit — Unified Folder Structure

This document outlines the production-ready directory structure for **Delhi OneTransit**. The system is built with modularity and Clean Architecture separation so that it can be deployed independently, while remaining easy to understand and maintain.

```text
delhi-onetransit/
├── .env.example                 # Environment variables specification
├── .gitignore                   # Workspace gitignore rules
├── index.html                   # Vite development SPA server page
├── metadata.json                # Platform capability metadata
├── package.json                 # Node package configuration
├── tsconfig.json                # TypeScript compilation config
├── vite.config.ts               # Vite configuration (HMR rules & aliases)
│
├── docs/                        # Architectural Diagrams & Design Docs
│   ├── FOLDER_STRUCTURE.md      # This folder layout document
│   ├── DATABASE_DESIGN.md       # ER diagram details & constraints
│   └── DEPLOYMENT_GUIDE.md      # DevOps and setup procedures
│
├── database/                    # Neon PostgreSQL migrations and seed data
│   ├── sql/
│   │   ├── 01_schema.sql        # Main raw SQL schema script (25+ tables)
│   │   └── 02_seed.sql          # Delhi Metro, DTC routes & fares mock-real seed
│   └── alembic.ini              # Python DB migration config
│
├── backend/                     # fastapi production backend source
│   ├── requirements.txt         # Python dependencies
│   ├── Dockerfile               # FastAPI container configuration
│   └── app/
│       ├── __init__.py
│       ├── main.py              # Application entry point, CORS, Swagger bootstrap
│       ├── core/                # System core parameters
│       │   ├── __init__.py
│       │   ├── config.py        # Environmental settings validation via spec
│       │   ├── security.py      # BCrypt password hashing & JWT token issuance
│       │   └── database.py      # SQLAlchemy DB engine & SessionLocal pools
│       │
│       ├── models/              # Clean Declarative SQLAlchemy models (ORMs)
│       │   ├── __init__.py
│       │   ├── base.py          # Shared Declarative Base helper
│       │   ├── user.py          # User, Profiles, Roles, and Sessions
│       │   ├── transit.py       # Stations, Lines, Routes, BusStops, Slabs
│       │   ├── wallet.py        # Smart Wallet, Passes, Transactions, Refunds
│       │   └── history.py       # Travel Journals and Activity Logs
│       │
│       ├── schemas/             # Pydantic Schemas for type-safe validation
│       │   ├── __init__.py
│       │   ├── user.py          # Token, Auth, Signup/Login, Password Change
│       │   ├── transit.py       # Route inputs, dynamic structures
│       │   ├── wallet.py        # WALLET transactions, pass purchase API specs
│       │   └── history.py       # Travel Log schema list validation
│       │
│       ├── repositories/        # Repository Pattern (Data access isolation)
│       │   ├── __init__.py
│       │   ├── base.py          # Generic generic repository definition
│       │   ├── user.py          # Specialized DB querying for users & sessions
│       │   ├── transit.py       # Specialized DB querying for stations & timetables
│       │   ├── wallet.py        # Wallet transactional atomicity controls
│       │   └── history.py       # Query filters for historical telemetry
│       │
│       ├── services/            # Business Logic Layer (Clean Service Layer)
│       │   ├── __init__.py
│       │   ├── auth.py          # Session operations, password verify, role checks
│       │   ├── route_planner.py # Dijkstra & A* multimodal route calculations
│       │   ├── fare_engine.py   # Multi-mode fare computations (Metro discount, DTC, etc)
│       │   └── wallet.py        # Cash-in, balance verification, pass activation
│       │
│       └── api/                 # FastAPI REST API Controllers (V1)
│           ├── __init__.py
│           └── v1/
│               ├── __init__.py
│               ├── auth.py      # Authenticated user creation, password recovery
│               ├── router.py    # Route Planner search & comparison endpoints
│               ├── wallet.py    # Wallet recharges, pass purchases, and refunds API
│               ├── history.py   # Logs retrieval & analytics dashboard support
│               └── admin.py     # Admin control points for routes & slabs management
│
└── src/                         # Full React 18 Frontend Core (Preview-ready)
    ├── main.tsx                 # Base loader and styles bridge
    ├── index.css                # Global styles with Tailwind integration
    ├── App.tsx                  # Main route director, context, and layouts
    ├── types.ts                 # Shared Typescript declarations 
    ├── components/              # UI widgets and reusable modules
    │   ├── Sidebar.tsx          # Dual-mode responsive side-dock nav
    │   ├── RouteCard.tsx        # Styled transit direction details component
    │   ├── MapCanvas.tsx        # Interactive SVG Delhi NCR map and routing path visual
    │   ├── StatCard.tsx         # Modern glassmorphism analytics metric
    │   └── AdminForm.tsx        # Modal forms for Admin control panels
    └── views/                   # Independent Pages components
        ├── Landing.tsx          # Landing Hero page
        ├── Login.tsx            # Login with OTP toggle panel
        ├── Signup.tsx           # Signup screen
        ├── Dashboard.tsx        # Live user overview
        ├── RoutePlanner.tsx     # Intelligent search & routing page
        ├── Wallet.tsx           # Wallet card rechargers, logs, passes
        ├── TravelHistory.tsx    # Scrollable journey reports
        ├── Analytics.tsx        # Dynamic dashboard displaying carbon reductions & Recharts graphs
        ├── Profile.tsx          # Profile & key preferences settings
        └── AdminDashboard.tsx   # Stations, users, transaction log controls
```

### 4. Explanation
This folder structure strictly complies with core software engineering patterns:
- **Separation of Concerns:** Low-level operations (SQL/Alembic) are strictly segregated from business processes (Services) and network controllers (API routes).
- **Independent Deployability:** The `/backend` is package-ready (with `requirements.txt` and `Dockerfile`) for Render/Heroku, while the `/src` is bundle-ready (using Vite) for Vercel.
- **Repository Pattern & DI:** Simplifies swap-outs (from Neon PostgreSQL to local sqlite for testing) without altering critical service logic.
- **Vite Integration:** The root folder enables direct interactive showcase previews inside AI Studio so we can immediately compile and test changes.
