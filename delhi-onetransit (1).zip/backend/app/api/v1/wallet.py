# backend/app/api/v1/wallet.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.services.wallet import wallet_service
from backend.app.api.v1.auth import get_current_user
from backend.app.models.user import User
from backend.app.schemas.wallet import WalletRecharge, WalletTransactionResponse, PassPurchase, PassResponse
from typing import Dict, Any

router = APIRouter(prefix="/wallet", tags=["Smart Wallet & Passes"])

@router.get("", response_model=Dict[str, Any])
def get_wallet_details(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """
    Returns prepaid card details, transactions ledger, and purchased passes.
    """
    summary = wallet_service.retrieve_wallet_summary(db, user_id=current_user.id)
    return summary


@router.post("/recharge", response_model=WalletTransactionResponse)
def recharge_wallet(
    payload: WalletRecharge, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    """
    Simulates high-speed payment gateway recharges.
    """
    try:
        txn = wallet_service.topup_wallet(
            db, user_id=current_user.id, amount=payload.amount, method=payload.payment_method
        )
        if not txn:
            raise HTTPException(status_code=400, detail="Recharge failure - wallet could not be resolved")
        return txn
    except ValueError as val_err:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(val_err))


@router.post("/purchase_pass", response_model=PassResponse)
def buy_transit_pass(
    payload: PassPurchase, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    """
    Charges wallet balance and activates monthly sub passes.
    """
    try:
        transit_pass = wallet_service.purchase_transit_subscription(
            db,
            user_id=current_user.id,
            pass_type=payload.pass_type,
            mode=payload.transport_mode,
            price=payload.price
        )
        return transit_pass
    except ValueError as val_err:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(val_err))
