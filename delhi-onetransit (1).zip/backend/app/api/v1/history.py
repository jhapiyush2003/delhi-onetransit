# backend/app/api/v1/history.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.repositories.history import history_repo
from backend.app.api.v1.auth import get_current_user
from backend.app.models.user import User
from backend.app.models.history import TravelTrip, TravelTripLeg
from backend.app.schemas.history import TravelTripCreate, TravelTripResponse, AnalyticsDashboardResponse
from typing import List

router = APIRouter(prefix="/history", tags=["Travel History & Analytics"])

@router.get("", response_model=List[TravelTripResponse])
def fetch_journey_history(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """
    Returns user travel reports.
    """
    trips = history_repo.get_user_trips(db, user_id=current_user.id)
    return trips


@router.post("/log_trip", response_model=TravelTripResponse)
def commit_journey_trip(
    payload: TravelTripCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    """
    Logs completed rides into user profiles database history.
    """
    trip_model = TravelTrip(
        user_id=current_user.id,
        source_address=payload.source_address,
        destination_address=payload.destination_address,
        total_fare=payload.total_fare,
        total_distance_km=payload.total_distance_km,
        total_duration_minutes=payload.total_duration_minutes,
        co2_saved_g=payload.co2_saved_g,
        start_time=payload.start_time,
        end_time=payload.end_time
    )

    legs = []
    for leg_schema in payload.legs:
        legs.append(TravelTripLeg(
            transport_code=leg_schema.transport_code,
            source_name=leg_schema.source_name,
            destination_name=leg_schema.destination_name,
            fare=leg_schema.fare,
            distance_km=leg_schema.distance_km,
            duration_minutes=leg_schema.duration_minutes
        ))

    journey = history_repo.log_journey(db, user_id=current_user.id, trip_in=trip_model, legs_in=legs)
    return journey


@router.get("/analytics", response_model=AnalyticsDashboardResponse)
def get_user_analytics_dashboard(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """
    Compiles aggregate metrics (Co2 offset progress, spending curves) formatted for graphs.
    """
    stats = history_repo.calculate_user_analytics(db, user_id=current_user.id)
    return stats
