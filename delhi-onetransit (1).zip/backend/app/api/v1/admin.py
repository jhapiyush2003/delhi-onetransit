# backend/app/api/v1/admin.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.api.v1.auth import get_current_user
from backend.app.models.user import User
from backend.app.models.transit import MetroStation, BusRoute, MetroLine
from backend.app.models.wallet import WalletTransaction
from backend.app.schemas.user import UserResponse
from backend.app.schemas.transit import MetroStationResponse, MetroStationCreate, BusRouteResponse, BusRouteCreate
from typing import List

router = APIRouter(prefix="/admin", tags=["Admin Panel Management"])

def ensure_admin(current_user: User = Depends(get_current_user)):
    """
    Guards paths restricting entry to System Admins.
    """
    if current_user.role != "Admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Forbidden - Requires Admin authority privileges"
        )
    return current_user


@router.get("/users", response_model=List[UserResponse])
def get_all_users(admin: User = Depends(ensure_admin), db: Session = Depends(get_db)):
    """
    Retrieves complete lists of passenger profile accounts.
    """
    return db.query(User).all()


@router.get("/transactions", response_model=List[dict])
def get_audit_transactions(admin: User = Depends(ensure_admin), db: Session = Depends(get_db)):
    """
    Lists system-wide prepaid card top-ups and ticket expenditures.
    """
    txs = db.query(WalletTransaction).all()
    # Serialize cleanly
    return [
        {
            "id": str(t.id),
            "wallet_id": str(t.wallet_id),
            "amount": t.amount,
            "transaction_type": t.transaction_type,
            "description": t.description,
            "reference_id": t.reference_id,
            "status": t.status,
            "created_at": t.created_at
        } for t in txs
    ]


@router.post("/metro/stations", response_model=MetroStationResponse)
def create_metro_station(
    payload: MetroStationCreate, admin: User = Depends(ensure_admin), db: Session = Depends(get_db)
):
    """
    Adds a new physical station point configuration.
    """
    existing = db.query(MetroStation).filter(MetroStation.name == payload.name).first()
    if existing:
        raise HTTPException(status_code=400, detail="Metro station name already registered")

    db_station = MetroStation(
        name=payload.name,
        latitude=payload.latitude,
        longitude=payload.longitude,
        is_interchange=payload.is_interchange,
        has_elevator=payload.has_elevator,
        has_parking=payload.has_parking
    )
    db.add(db_station)
    db.commit()
    db.refresh(db_station)
    return db_station


@router.post("/bus/routes", response_model=BusRouteResponse)
def create_bus_route(
    payload: BusRouteCreate, admin: User = Depends(ensure_admin), db: Session = Depends(get_db)
):
    """
    Registers a new DTC green/red routes map.
    """
    existing = db.query(BusRoute).filter(BusRoute.route_code == payload.route_code).first()
    if existing:
        raise HTTPException(status_code=400, detail="Route code already active")

    db_route = BusRoute(
        route_code=payload.route_code,
        source_stop=payload.source_stop,
        destination_stop=payload.destination_stop,
        is_ac=payload.is_ac
    )
    db.add(db_route)
    db.commit()
    db.refresh(db_route)
    return db_route
