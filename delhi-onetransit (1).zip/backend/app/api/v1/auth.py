# backend/app/api/v1/auth.py
from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.services.auth import auth_service
from backend.app.repositories.user import user_repo
from backend.app.models.user import User
from backend.app.schemas.user import (
    UserCreate, UserLogin, Token, TokenRefresh, UserResponse, UserProfileUpdate
)
import uuid

router = APIRouter(prefix="/auth", tags=["Authentication"])

def get_current_user(request: Request, db: Session = Depends(get_db)) -> User:
    """
    Dependency checking the Authorization header to verify caller identity.
    """
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing or invalid token credentials")

    token = auth_header.split(" ")[1]
    payload = auth_service.verify_token(token)
    if not payload:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Expired or corrupted credential signature")

    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token properties")

    user = user_repo.get(db, id=uuid.UUID(user_id))
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Transit account not found")
    return user


@router.post("/signup", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def signup(payload: UserCreate, db: Session = Depends(get_db)):
    try:
        user = auth_service.signup_user(db, email=payload.email, password=payload.password, full_name=payload.full_name)
        return user
    except ValueError as err:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(err))


@router.post("/login", response_model=Token)
def login(payload: UserLogin, request: Request, db: Session = Depends(get_db)):
    # Pull metadata for audits
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("user-agent", "unknown")
    
    result = auth_service.login_user(db, email=payload.email, password=payload.password, ip=ip, ua=ua)
    if not result:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect email or password combination")

    return result["tokens"]


@router.post("/refresh", response_model=Token)
def refresh_token(payload: TokenRefresh, db: Session = Depends(get_db)):
    result = auth_service.refresh_user_token(db, refresh_token=payload.refresh_token)
    if not result:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or deceased refresh token")

    # Mirror a complete object back
    return {
        "access_token": result["access_token"],
        "refresh_token": payload.refresh_token,
        "token_type": "bearer"
    }


@router.get("/profile", response_model=UserResponse)
def get_user_profile(current_user: User = Depends(get_current_user)):
    return current_user


@router.put("/profile", response_model=UserResponse)
def update_user_profile(
    payload: UserProfileUpdate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    profile = current_user.profile
    if not profile:
        raise HTTPException(status_code=404, detail="Profile record missing")

    # Update attributes
    for key, val in payload.dict(exclude_unset=True).items():
        setattr(profile, key, val)

    db.add(profile)
    db.commit()
    db.refresh(current_user)
    return current_user
