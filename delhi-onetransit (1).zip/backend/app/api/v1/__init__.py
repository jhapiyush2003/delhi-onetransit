# backend/app/api/v1/__init__.py
from backend.app.api.v1.auth import router as auth_router
from backend.app.api.v1.router import router as path_router
from backend.app.api.v1.wallet import router as finance_router
from backend.app.api.v1.history import router as journal_router
from backend.app.api.v1.admin import router as control_router
