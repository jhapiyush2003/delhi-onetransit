# backend/app/api/v1/router.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.services.route_planner import route_planner_service, DELHI_NODES
from backend.app.schemas.transit import RouteQuery, MultimodalRouteResponse
from typing import List, Dict, Any

router = APIRouter(prefix="/router", tags=["Route Planner Engine"])

@router.post("/search", response_model=MultimodalRouteResponse)
def search_transit_routes(payload: RouteQuery):
    """
    Retrieves the mathematically optimal transit path across Metro and bus systems.
    """
    try:
        route_details = route_planner_service.search_route(
            source=payload.source,
            destination=payload.destination,
            priority=payload.priority
        )
        return route_details
    except KeyError as k_err:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(k_err)
        )
    except Exception as err:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Routing failure: {str(err)}"
        )


@router.get("/landmarks", response_model=Dict[str, Dict[str, Any]])
def get_transit_landmarks():
    """
    Exposes geo-anchors for maps.
    """
    return DELHI_NODES
