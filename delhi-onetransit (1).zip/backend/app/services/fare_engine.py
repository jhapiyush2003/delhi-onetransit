# backend/app/services/fare_engine.py
from typing import Dict, Any

class TransitFareEngine:
    """
    Unified Ticket Pricing Calculations Engine for Delhi NCR.
    """
    def calculate_metro_fare(self, distance_km: float, is_smart_card: bool = True) -> float:
        # standard DMRC distance slab pricing
        if distance_km <= 2.0:
            base_fare = 10.0
        elif distance_km <= 5.0:
            base_fare = 20.0
        elif distance_km <= 12.0:
            base_fare = 30.0
        elif distance_km <= 21.0:
            base_fare = 40.0
        elif distance_km <= 32.0:
            base_fare = 50.0
        else:
            base_fare = 60.0

        if is_smart_card:
            # Apply 10% smart card discount
            return round(base_fare * 0.9, 2)
        return float(base_fare)

    def calculate_bus_fare(self, distance_km: float, is_ac: bool = False) -> float:
        # DTC Flat distance structure
        if is_ac:
            # AC buses: FLAT slabs
            if distance_km <= 4.0:
                return 10.0
            elif distance_km <= 8.0:
                return 15.0
            elif distance_km <= 12.0:
                return 20.0
            else:
                return 25.0
        else:
            # Ordinary (CNG green buses) flat rates
            if distance_km <= 4.0:
                return 5.0
            elif distance_km <= 10.0:
                return 10.0
            else:
                return 15.0

    def calculate_train_fare(self, distance_km: float, class_type: str = "General") -> float:
        # Indian Railways EMU fares
        if distance_km <= 20.0:
            return 10.0
        elif distance_km <= 45.0:
            return 15.0
        elif distance_km <= 75.0:
            return 20.0
        else:
            return 30.0

    def calculate_rickshaw_fare(self, distance_km: float, is_shared: bool = True) -> float:
        # Local battery rickshaws rules
        if is_shared:
            return 10.0  # standard shared ride fare in university grids
        else:
            # private hire base structures
            return 15.0 + max(0.0, (distance_km - 1.0) * 10.0)

    def compute_journey_legs_fares(self, legs: list) -> float:
        """
        Receives leg details, computes independent fares, and returns the unified sum.
        """
        total = 0.0
        for leg in legs:
            mode = leg.get("transport_mode")
            dist = leg.get("distance_km", 0.0)

            if mode == "METRO":
                total += self.calculate_metro_fare(dist, is_smart_card=True)
            elif mode == "BUS":
                is_ac = leg.get("is_ac", False)
                total += self.calculate_bus_fare(dist, is_ac=is_ac)
            elif mode == "TRAIN":
                total += self.calculate_train_fare(dist)
            elif mode == "RICKSHAW":
                is_shared = leg.get("is_shared", True)
                total += self.calculate_rickshaw_fare(dist, is_shared=is_shared)
            elif mode == "WALK":
                total += 0.0
        return round(total, 2)

# Expose singleton
fare_engine_service = TransitFareEngine()
