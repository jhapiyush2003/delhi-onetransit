# backend/app/services/wallet.py
import datetime
import uuid
from typing import Optional, List, Dict, Any
from sqlalchemy.orm import Session
from backend.app.repositories.wallet import wallet_repo
from backend.app.models.wallet import Wallet, TransitPass, WalletTransaction

class WalletService:
    """
    Handles business validations for balance recharges, pass purchases, and secure ticketing payments.
    """
    def topup_wallet(self, db: Session, user_id: uuid.UUID, amount: float, method: str = "UPI") -> Optional[WalletTransaction]:
        if amount <= 0:
            raise ValueError("Recharge amount must exceed zero INR")
        if amount > 5000:
            raise ValueError("Single topup limit is cap at 5000 INR")

        wallet = wallet_repo.get_by_user_id(db, user_id=user_id)
        if not wallet:
            # Lazy initialize wallet if somehow missing
            wallet = wallet_repo.create_wallet(db, user_id=user_id, initial_balance=0.0)

        desc = f"Wallet Recharge via {method}"
        return wallet_repo.execute_transaction(db, wallet_id=wallet.id, amount=amount, txn_type="credit", desc=desc)

    def retrieve_wallet_summary(self, db: Session, user_id: uuid.UUID) -> Dict[str, Any]:
        wallet = wallet_repo.get_by_user_id(db, user_id=user_id)
        if not wallet:
            wallet = wallet_repo.create_wallet(db, user_id=user_id, initial_balance=150.0) # default initial free balance load

        txs = wallet_repo.get_user_transactions(db, wallet_id=wallet.id)
        passes = wallet_repo.get_active_passes(db, user_id=user_id)

        # Map to matching JSON layout
        return {
            "wallet": {
                "id": str(wallet.id),
                "balance": wallet.balance,
                "status": wallet.status,
                "updated_at": wallet.updated_at
            },
            "transactions": [
                {
                    "id": str(t.id),
                    "amount": t.amount,
                    "transaction_type": t.transaction_type,
                    "description": t.description,
                    "reference_id": t.reference_id,
                    "status": t.status,
                    "created_at": t.created_at
                } for t in txs[:15]  # Limit past 15 txs
            ],
            "active_passes": [
                {
                    "id": str(p.id),
                    "pass_type": p.pass_type,
                    "transport_mode": p.transport_mode,
                    "price": p.price,
                    "starts_at": p.starts_at,
                    "expires_at": p.expires_at,
                    "is_active": p.is_active
                } for p in passes
            ]
        }

    def purchase_transit_subscription(
        self, db: Session, user_id: uuid.UUID, pass_type: str, mode: str, price: float
    ) -> Optional[TransitPass]:
        """
        Deducts cost from wallet and registers active pass.
        """
        wallet = wallet_repo.get_by_user_id(db, user_id=user_id)
        if not wallet or wallet.balance < price:
            raise ValueError("Insufficient balance in your Delhi OneTransit wallet to buy this pass")

        desc = f"Subscribed Pass: {pass_type}"
        # Deduct wallet balance atomically
        wallet_repo.execute_transaction(db, wallet_id=wallet.id, amount=price, txn_type="debit", desc=desc)

        # Create Pass
        start = datetime.datetime.utcnow()
        expiry = start + datetime.timedelta(days=30)  # Standard 30 days passes

        new_pass = TransitPass(
            user_id=user_id,
            pass_type=pass_type,
            transport_mode=mode,
            price=price,
            starts_at=start,
            expires_at=expiry,
            is_active=True
        )
        return wallet_repo.purchase_pass(db, user_id=user_id, pass_item=new_pass)

# Expose singleton
wallet_service = WalletService()
