# backend/app/services/auth.py
import datetime
import jwt
from typing import Optional, Dict, Any
from backend.app.core.security import get_password_hash, verify_password
from backend.app.repositories.user import user_repo
from backend.app.models.user import User
from sqlalchemy.orm import Session

# Configuration defaults (normally loaded from backend/app/core/config.py)
JWT_SECRET = "DELHI_ONETRANSIT_SECURE_TOKEN_SIGNATURE_KEY_RECRUITERS_2026"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
REFRESH_TOKEN_EXPIRE_DAYS = 7

class AuthService:
    """
    Main authentication business service orchestrating cryptographic credentials checks and JWT sessions.
    """
    def signup_user(self, db: Session, email: str, password: str, full_name: str) -> Optional[User]:
        existing = user_repo.get_by_email(db, email=email)
        if existing:
            raise ValueError("Email address already registered in OneTransit")

        p_hash = get_password_hash(password)
        new_user = User(
            email=email,
            full_name=full_name,
            role="User",
            status="active",
            is_verified=True # Auto-verified for instant showcase access
        )
        return user_repo.create_user_with_profile(db, user_in=new_user, password_hash=p_hash)

    def login_user(self, db: Session, email: str, password: str, ip: str = None, ua: str = None) -> Optional[Dict[str, Any]]:
        user = user_repo.get_by_email(db, email=email)
        if not user or user.status != "active":
            return None

        p_obj = user_repo.get_password(db, user_id=user.id)
        if not p_obj or not verify_password(password, p_obj.password_hash):
            user_repo.add_login_log(db, user_id=user.id, ip=ip, ua=ua, status=False)
            return None

        # Record successful log
        user_repo.add_login_log(db, user_id=user.id, ip=ip, ua=ua, status=True)

        # Build JWT Tokens
        access = self.create_access_token(user_id=str(user.id), role=user.role)
        refresh = self.create_refresh_token(user_id=str(user.id))

        # Persist refresh token in db
        exp_time = datetime.datetime.utcnow() + datetime.timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
        user_repo.save_refresh_token(db, user_id=user.id, token=refresh, expiration=exp_time, device=ua)

        return {
            "user": user,
            "tokens": {
                "access_token": access,
                "refresh_token": refresh,
                "token_type": "bearer"
            }
        }

    def refresh_user_token(self, db: Session, refresh_token: str) -> Optional[Dict[str, str]]:
        rt = user_repo.get_refresh_token(db, token=refresh_token)
        if not rt or rt.is_revoked or rt.expires_at < datetime.datetime.utcnow():
            return None

        user = rt.user
        if user.status != "active":
            return None

        access = self.create_access_token(user_id=str(user.id), role=user.role)
        return {
            "access_token": access,
            "token_type": "bearer"
        }

    def logout_user(self, db: Session, token: str) -> None:
        user_repo.revoke_refresh_token(db, token=token)

    def create_access_token(self, user_id: str, role: str) -> str:
        payload = {
            "sub": user_id,
            "role": role,
            "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES),
            "iat": datetime.datetime.utcnow()
        }
        return jwt.encode(payload, JWT_SECRET, algorithm=ALGORITHM)

    def create_refresh_token(self, user_id: str) -> str:
        payload = {
            "sub": user_id,
            "exp": datetime.datetime.utcnow() + datetime.timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS),
            "iat": datetime.datetime.utcnow()
        }
        return jwt.encode(payload, JWT_SECRET, algorithm=ALGORITHM)

    def verify_token(self, token: str) -> Optional[Dict[str, Any]]:
        try:
            payload = jwt.decode(token, JWT_SECRET, algorithms=[ALGORITHM])
            return payload
        except jwt.PyJWTError:
            return None

# Expose singleton
auth_service = AuthService()
