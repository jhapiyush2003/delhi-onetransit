# backend/app/main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.app.core.database import Base, engine, SessionLocal
from backend.app.api.v1.auth import router as auth_router
from backend.app.api.v1.router import router as path_router
from backend.app.api.v1.wallet import router as finance_router
from backend.app.api.v1.history import router as journal_router
from backend.app.api.v1.admin import router as control_router

# Auto-create all SQLAlchemy database tables when starting
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Delhi OneTransit API",
    description="Unified Smart Mobility Platform Backend for Delhi NCR - Multi-Modal Routing, Ticketing, Wallets, and Analytics",
    version="1.0.0"
)

# Active CORS policies for React frontend connections
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Permits rapid integration on local or staging preview servers
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount API Routers
app.include_router(auth_router, prefix="/api/v1")
app.include_router(path_router, prefix="/api/v1")
app.include_router(finance_router, prefix="/api/v1")
app.include_router(journal_router, prefix="/api/v1")
app.include_router(control_router, prefix="/api/v1")


@app.get("/", tags=["Root"])
def root_status_check():
    """
    Health check utility checking service viability.
    """
    return {
        "status": "online",
        "service": "Delhi OneTransit Unified Smart Mobility API Gateway",
        "version": "1.0.0",
        "ncr_coverage_centers": [
            "New Delhi", "Gurugram", "Noida", "Ghaziabad", "Faridabad"
        ]
    }


# Auto-seeder execution to populate default lines and pricing matrices on boot
def seed_initial_datasets():
    db = SessionLocal()
    from backend.app.models.transit import MetroStation, MetroLine, MetroLineStation, BusRoute, BusStop, ERickshawZone, TransportMode
    from backend.app.models.user import User, UserPassword
    from backend.app.core.security import get_password_hash

    try:
        # 1. Seed Transport Modes
        if db.query(TransportMode).count() == 0:
            modes = [
                TransportMode(name="Delhi Metro", code="METRO", co2_saved_g_per_km=135.5),
                TransportMode(name="DTC Bus", code="BUS", co2_saved_g_per_km=128.0),
                TransportMode(name="Local Train", code="TRAIN", co2_saved_g_per_km=122.0),
                TransportMode(name="E-Rickshaw", code="RICKSHAW", co2_saved_g_per_km=138.0),
                TransportMode(name="Walking", code="WALK", co2_saved_g_per_km=140.0),
            ]
            db.add_all(modes)
            db.commit()

        # 2. Seed Metro Lines
        if db.query(MetroLine).count() == 0:
            lines = [
                MetroLine(name="Yellow Line", color_hex="#FFDD00"),
                MetroLine(name="Blue Line", color_hex="#0000FF"),
            ]
            db.add_all(lines)
            db.commit()

        # 3. Seed Metro Stations
        if db.query(MetroStation).count() == 0:
            stations = [
                MetroStation(name="Rajiv Chowk", latitude=28.6304, longitude=77.2177, is_interchange=True),
                MetroStation(name="Kashmere Gate", latitude=28.6675, longitude=77.2281, is_interchange=True),
                MetroStation(name="GTB Nagar", latitude=28.6922, longitude=77.2078, is_interchange=False),
                MetroStation(name="HUDA City Centre", latitude=28.4593, longitude=77.0724, is_interchange=False),
                MetroStation(name="Noida Sector 62", latitude=28.6219, longitude=77.3639, is_interchange=False),
                # Bus connections
                MetroStation(name="New Delhi Station", latitude=28.6418, longitude=77.2219, is_interchange=True),
                MetroStation(name="Anand Vihar", latitude=28.6468, longitude=77.3160, is_interchange=True),
            ]
            db.add_all(stations)
            db.commit()

            # Seed Metro junctions sequences
            y_line = db.query(MetroLine).filter(MetroLine.name == "Yellow Line").first()
            b_line = db.query(MetroLine).filter(MetroLine.name == "Blue Line").first()

            s_rc = db.query(MetroStation).filter(MetroStation.name == "Rajiv Chowk").first()
            s_kg = db.query(MetroStation).filter(MetroStation.name == "Kashmere Gate").first()
            s_gt = db.query(MetroStation).filter(MetroStation.name == "GTB Nagar").first()
            s_hc = db.query(MetroStation).filter(MetroStation.name == "HUDA City Centre").first()
            s_nd = db.query(MetroStation).filter(MetroStation.name == "New Delhi Station").first()
            s_av = db.query(MetroStation).filter(MetroStation.name == "Anand Vihar").first()
            s_n62 = db.query(MetroStation).filter(MetroStation.name == "Noida Sector 62").first()

            # Yellow Line sequences ordering
            y_seq = [
                MetroLineStation(line_id=y_line.id, station_id=s_gt.id, sequence_order=1),
                MetroLineStation(line_id=y_line.id, station_id=s_kg.id, sequence_order=2),
                MetroLineStation(line_id=y_line.id, station_id=s_nd.id, sequence_order=3),
                MetroLineStation(line_id=y_line.id, station_id=s_rc.id, sequence_order=4),
                MetroLineStation(line_id=y_line.id, station_id=s_hc.id, sequence_order=5),
            ]
            db.add_all(y_seq)

            # Blue Line sequences ordering
            b_seq = [
                MetroLineStation(line_id=b_line.id, station_id=s_rc.id, sequence_order=1),
                MetroLineStation(line_id=b_line.id, station_id=s_av.id, sequence_order=2),
                MetroLineStation(line_id=b_line.id, station_id=s_n62.id, sequence_order=3),
            ]
            db.add_all(b_seq)
            db.commit()

        # 4. Seed DTC Bus Networks
        if db.query(BusRoute).count() == 0:
            routes = [
                BusRoute(route_code="502", source_stop="GTB Nagar", destination_stop="Kashmere Gate", is_ac=False),
                BusRoute(route_code="419", source_stop="Kashmere Gate", destination_stop="Hazrat Nizamuddin", is_ac=True),
                BusRoute(route_code="604", source_stop="Vasant Kunj Sector C", destination_stop="Rajiv Chowk", is_ac=True),
            ]
            db.add_all(routes)
            db.commit()

        # 5. Seed Rickshaw Zones
        if db.query(ERickshawZone).count() == 0:
            zones = [
                ERickshawZone(name="GTB Nagar Hub", central_latitude=28.6922, central_longitude=77.2078),
                ERickshawZone(name="Rajiv Chowk CP Hub", central_latitude=28.6304, central_longitude=77.2177),
            ]
            db.add_all(zones)
            db.commit()

        # 6. Seed Demo Recruiter admin account (Email: recruiter@onetransit.in / Pass: recruiter123)
        if db.query(User).filter(User.email == "recruiter@onetransit.in").count() == 0:
            recruiter = User(
                email="recruiter@onetransit.in",
                full_name="Elite Recruiter",
                role="Admin",
                is_verified=True,
                status="active"
            )
            db.add(recruiter)
            db.flush()

            # Set password hash
            rec_pass = UserPassword(
                user_id=recruiter.id,
                password_hash=get_password_hash("recruiter123")
            )
            db.add(rec_pass)

            # Pre-init static wallet
            from backend.app.models.wallet import Wallet, WalletTransaction
            rec_wallet = Wallet(user_id=recruiter.id, balance=750.0)
            db.add(rec_wallet)
            db.flush()

            cre_tx = WalletTransaction(
                wallet_id=rec_wallet.id,
                amount=750.0,
                transaction_type="credit",
                description="Recruiter Sign-On Welcome Bonus Balance",
                reference_id="TXN-WELCOME750",
                status="completed"
            )
            db.add(cre_tx)
            db.commit()

    except Exception as e:
        db.rollback()
        print(f"Error seeding database: {e}")
    finally:
        db.close()

seed_initial_datasets()
