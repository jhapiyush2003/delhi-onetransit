# backend/app/core/security.py
import hashlib

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Checks the user's plain password against the registered SHA256 storage.
    """
    salted = f"DELHI_METRO_SALT_KEY_2026_{plain_password}"
    computed = hashlib.sha256(salted.encode()).hexdigest()
    return computed == hashed_password

def get_password_hash(password: str) -> str:
    """
    Produces a Salted SHA256 secure hash to protect against database leak indexing.
    """
    salted = f"DELHI_METRO_SALT_KEY_2026_{password}"
    return hashlib.sha256(salted.encode()).hexdigest()
