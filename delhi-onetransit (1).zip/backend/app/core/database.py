# backend/app/core/database.py
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Default to modular sqlite during dev so preview runs smoothly inside the virtual workspace
# Support overrides via standard environment variables (Neon PostgreSQL connection string)
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./delhi_onetransit.db")

# Adjust engine parameters based on database engine
if DATABASE_URL.startswith("sqlite"):
    engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
else:
    engine = create_engine(DATABASE_URL, pool_size=10, max_overflow=20)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    """
    Yields independent database sessions to requests, making sure transactions close.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
