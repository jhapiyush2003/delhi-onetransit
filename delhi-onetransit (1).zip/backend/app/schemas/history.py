# backend/app/schemas/history.py
from pydantic import BaseModel
from typing import List, Optional, Dict
from datetime import datetime
from uuid import UUID

class TravelTripLegResponse(BaseModel):
    id: UUID
    transport_code: str
    source_name: str
    destination_name: str
    fare: float
    distance_km: float
    duration_minutes: float
    sequence_order: int

    class Config:
        from_attributes = True

class TravelTripCreate(BaseModel):
    source_address: str
    destination_address: str
    total_fare: float
    total_distance_km: float
    total_duration_minutes: float
    co2_saved_g: float
    start_time: datetime
    end_time: datetime
    legs: List[TravelTripLegResponse]

class TravelTripResponse(BaseModel):
    id: UUID
    source_address: str
    destination_address: str
    total_fare: float
    total_distance_km: float
    total_duration_minutes: float
    co2_saved_g: float
    start_time: datetime
    end_time: datetime
    legs: List[TravelTripLegResponse]

    class Config:
        from_attributes = True

class MonthlySpendingItem(BaseModel):
    month: str  # e.g., "Jan", "Feb"
    amount: float

class ModeUsageItem(BaseModel):
    mode: str  # e.g., "METRO", "BUS", "WALK", "RICKSHAW"
    trips: int

class AnalyticsDashboardResponse(BaseModel):
    total_spending_inr: float
    total_trips_conducted: int
    average_distance_km: float
    most_used_mode: str
    carbon_emissions_saved_g: float
    peak_travel_time_hour: str  # e.g. "09:00 AM - 10:00 AM"
    spending_history: List[MonthlySpendingItem]
    mode_distribution: List[ModeUsageItem]
