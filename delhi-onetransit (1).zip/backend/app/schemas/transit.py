# backend/app/schemas/transit.py
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime, time

class RouteQuery(BaseModel):
    """
    Search parameters for the multimodal Dijkstra/A* routing system.
    """
    source: str = Field(..., description="Source metro station name or custom GPS coordinates")
    destination: str = Field(..., description="Destination metro station name or custom GPS coordinates")
    priority: str = Field("fastest", description="Optimizer logic: fastest, cheapest, least_interchanges, lowest_walking")

class TransitLegResponse(BaseModel):
    """
    A single modal leg in a journey route (e.g., E-Rickshaw feeder, Metro core).
    """
    transport_mode: str  # "METRO", "BUS", "TRAIN", "RICKSHAW", "WALK"
    source_name: str
    destination_name: str
    distance_km: float
    duration_minutes: float
    fare: float
    line_name: Optional[str] = None  # and e.g., "Yellow Line" if METRO
    route_code: Optional[str] = None  # e.g., "502" if BUS

class MultimodalRouteResponse(BaseModel):
    """
    The completed multimodal trip path.
    """
    route_id: str
    legs: List[TransitLegResponse]
    total_fare: float
    total_distance_km: float
    total_duration_minutes: float
    carbon_saved_g: float
    number_of_interchanges: int

class MetroStationCreate(BaseModel):
    name: str
    latitude: float
    longitude: float
    is_interchange: bool = False
    has_elevator: bool = True
    has_parking: bool = False

class MetroStationResponse(BaseModel):
    id: int
    name: str
    latitude: float
    longitude: float
    is_interchange: bool
    has_elevator: bool
    has_parking: bool

    class Config:
        from_attributes = True

class BusRouteCreate(BaseModel):
    route_code: str
    source_stop: str
    destination_stop: str
    is_ac: bool = False

class BusRouteResponse(BaseModel):
    id: int
    route_code: str
    source_stop: str
    destination_stop: str
    is_ac: bool

    class Config:
        from_attributes = True

class StationNetworkMap(BaseModel):
    stations: List[MetroStationResponse]
    lines: List[str]
