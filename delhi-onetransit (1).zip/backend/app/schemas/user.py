# backend/app/schemas/user.py
from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import datetime
from uuid import UUID

class UserBase(BaseModel):
    email: EmailStr
    full_name: str = Field(..., min_length=2, max_length=100)

class UserCreate(UserBase):
    password: str = Field(..., min_length=6, max_length=100)

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"

class TokenRefresh(BaseModel):
    refresh_token: str

class PasswordChange(BaseModel):
    old_password: str
    new_password: str = Field(..., min_length=6)

class PasswordResetRequest(BaseModel):
    email: EmailStr

class PasswordResetConfirm(BaseModel):
    token: str
    new_password: str = Field(..., min_length=6)

class UserProfileUpdate(BaseModel):
    phone_number: Optional[str] = None
    preferred_language: Optional[str] = "en"
    home_latitude: Optional[str] = None
    home_longitude: Optional[str] = None
    work_latitude: Optional[str] = None
    work_longitude: Optional[str] = None

class UserProfileResponse(BaseModel):
    phone_number: Optional[str]
    preferred_language: str
    home_latitude: Optional[str]
    home_longitude: Optional[str]
    work_latitude: Optional[str]
    work_longitude: Optional[str]

    class Config:
        from_attributes = True

class UserResponse(UserBase):
    id: UUID
    role: str
    status: str
    is_verified: bool
    created_at: datetime
    profile: Optional[UserProfileResponse] = None

    class Config:
        from_attributes = True
