# backend/app/schemas/wallet.py
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from uuid import UUID

class WalletRecharge(BaseModel):
    """
    Input model for smart wallet recharge.
    """
    amount: float = Field(..., gt=0, lt=10000, description="Recharge amount in INR")
    payment_method: str = Field("UPI", description="UPI, NetBanking, CreditCard, DebitCard")

class WalletTransactionResponse(BaseModel):
    id: UUID
    amount: float
    transaction_type: str  # credit, debit, refund
    description: str
    status: str
    created_at: datetime

    class Config:
        from_attributes = True

class WalletResponse(BaseModel):
    id: UUID
    balance: float
    status: str
    updated_at: datetime

    class Config:
        from_attributes = True

class PassPurchase(BaseModel):
    pass_type: str  # "DTC Monthly Ordinary Bus", "Delhi Metro Tourist Pass", "EMU Pass"
    transport_mode: str  # METRO, BUS, TRAIN
    price: float

class PassResponse(BaseModel):
    id: UUID
    pass_type: str
    transport_mode: str
    price: float
    starts_at: datetime
    expires_at: datetime
    is_active: bool

    class Config:
        from_attributes = True
