# backend/app/repositories/user.py
from typing import Optional, List, Any
from sqlalchemy.orm import Session
from backend.app.repositories.base import BaseRepository
from backend.app.models.user import User, UserProfile, UserPassword, UserRefreshToken, UserLoginLog

class UserRepository(BaseRepository[User]):
    """
    Handles user records querying.
    """
    def __init__(self):
        super().__init__(User)

    def get_by_email(self, db: Session, email: str) -> Optional[User]:
        return db.query(User).filter(User.email == email).first()

    def create_user_with_profile(self, db: Session, *, user_in: User, password_hash: str) -> User:
        db.add(user_in)
        db.flush()  # Allocates ID to user_in

        # Direct passwords store
        p_obj = UserPassword(user_id=user_in.id, password_hash=password_hash)
        db.add(p_obj)

        # Profile parameters
        prof_obj = UserProfile(user_id=user_in.id)
        db.add(prof_obj)

        db.commit()
        db.refresh(user_in)
        return user_in

    def get_password(self, db: Session, user_id: Any) -> Optional[UserPassword]:
        return db.query(UserPassword).filter(UserPassword.user_id == user_id).first()

    def add_login_log(self, db: Session, user_id: Any, ip: str, ua: str, status: bool) -> UserLoginLog:
        log = UserLoginLog(user_id=user_id, ip_address=ip, user_agent=ua, is_success=status)
        db.add(log)
        db.commit()
        return log

    def save_refresh_token(self, db: Session, user_id: Any, token: str, expiration: Any, device: str = None) -> UserRefreshToken:
        # Revoke existing tokens for simplified single-session option (or append as needed)
        db.query(UserRefreshToken).filter(UserRefreshToken.user_id == user_id).update({"is_revoked": True})
        
        rt = UserRefreshToken(user_id=user_id, token=token, expires_at=expiration, device_info=device)
        db.add(rt)
        db.commit()
        return rt

    def get_refresh_token(self, db: Session, token: str) -> Optional[UserRefreshToken]:
        return db.query(UserRefreshToken).filter(UserRefreshToken.token == token, UserRefreshToken.is_revoked == False).first()

    def revoke_refresh_token(self, db: Session, token: str) -> None:
        db.query(UserRefreshToken).filter(UserRefreshToken.token == token).update({"is_revoked": True})
        db.commit()

# Expose singleton
user_repo = UserRepository()
