# backend/app/repositories/transit.py
from typing import List, Optional, Dict
from sqlalchemy.orm import Session
from backend.app.repositories.base import BaseRepository
from backend.app.models.transit import (
    MetroStation, MetroLine, MetroLineStation, MetroFare,
    BusRoute, BusStop, BusRouteStop, TrainStation, TrainFareSlab,
    ERickshawZone, ERickshawOperator
)

class TransitRepository:
    """
    Consolidated repository managing high-performance transit lookups.
    """
    # Metro Helpers
    def get_stations(self, db: Session) -> List[MetroStation]:
        return db.query(MetroStation).all()

    def get_station_by_name(self, db: Session, name: str) -> Optional[MetroStation]:
        return db.query(MetroStation).filter(MetroStation.name.ilike(name)).first()

    def get_lines(self, db: Session) -> List[MetroLine]:
        return db.query(MetroLine).all()

    def get_line_stations(self, db: Session, line_id: int) -> List[MetroLineStation]:
        return db.query(MetroLineStation).filter(MetroLineStation.line_id == line_id).order_by(MetroLineStation.sequence_order).all()

    def get_metro_fare_matrix(self, db: Session, o_name: str, d_name: str) -> Optional[MetroFare]:
        return db.query(MetroFare).filter(
            MetroFare.source_station_name.ilike(o_name),
            MetroFare.dest_station_name.ilike(d_name)
        ).first()

    # Bus Helpers
    def get_bus_routes(self, db: Session) -> List[BusRoute]:
        return db.query(BusRoute).all()

    def get_bus_route_stops(self, db: Session, route_id: int) -> List[BusRouteStop]:
        return db.query(BusRouteStop).filter(BusRouteStop.route_id == route_id).order_by(BusRouteStop.sequence_order).all()

    def get_bus_stop_by_name(self, db: Session, name: str) -> Optional[BusStop]:
        return db.query(BusStop).filter(BusStop.name.ilike(name)).first()

    # Train Helpers
    def get_train_stations(self, db: Session) -> List[TrainStation]:
        return db.query(TrainStation).all()

    def get_train_fare_slab(self, db: Session, distance: float) -> Optional[TrainFareSlab]:
        return db.query(TrainFareSlab).filter(
            TrainFareSlab.min_distance_km <= distance,
            TrainFareSlab.max_distance_km >= distance
        ).first()

    # Rickshaw Helpers
    def get_rickshaw_zones(self, db: Session) -> List[ERickshawZone]:
        return db.query(ERickshawZone).all()

    def get_rickshaw_zone_by_name(self, db: Session, name: str) -> Optional[ERickshawZone]:
        return db.query(ERickshawZone).filter(ERickshawZone.name.ilike(name)).first()

    def get_active_operators_by_zone(self, db: Session, zone_id: int) -> List[ERickshawOperator]:
        return db.query(ERickshawOperator).filter(
            ERickshawOperator.zone_id == zone_id,
            ERickshawOperator.is_active == True
        ).all()

# Expose singleton
transit_repo = TransitRepository()
