# backend/app/repositories/__init__.py
from backend.app.repositories.base import BaseRepository
from backend.app.repositories.user import user_repo, UserRepository
from backend.app.repositories.transit import transit_repo, TransitRepository
from backend.app.repositories.wallet import wallet_repo, WalletRepository
from backend.app.repositories.history import history_repo, TravelHistoryRepository
