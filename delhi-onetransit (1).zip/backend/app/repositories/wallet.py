# backend/app/repositories/wallet.py
import uuid
from typing import Optional, List
from sqlalchemy.orm import Session
from datetime import datetime
from backend.app.repositories.base import BaseRepository
from backend.app.models.wallet import Wallet, WalletTransaction, TransitPass

class WalletRepository(BaseRepository[Wallet]):
    """
    Handles wallet financial balances and pass purchase database changes.
    """
    def __init__(self):
        super().__init__(Wallet)

    def get_by_user_id(self, db: Session, user_id: uuid.UUID) -> Optional[Wallet]:
        return db.query(Wallet).filter(Wallet.user_id == user_id).first()

    def create_wallet(self, db: Session, user_id: uuid.UUID, initial_balance: float = 150.0) -> Wallet:
        wallet = Wallet(user_id=user_id, balance=initial_balance)
        db.add(wallet)
        db.commit()
        db.refresh(wallet)
        return wallet

    def execute_transaction(
        self, db: Session, wallet_id: uuid.UUID, amount: float, txn_type: str, desc: str
    ) -> Optional[WalletTransaction]:
        """
        Executes a balance deposit or debit transaction atomically.
        """
        wallet = db.query(Wallet).filter(Wallet.id == wallet_id).with_for_update().first()
        if not wallet:
            return None

        # Overdraft protection
        if txn_type == "debit" and wallet.balance < amount:
            raise ValueError("Insufficient wallet balance for this ticket")

        # Balance adjustment
        if txn_type == "credit" or txn_type == "refund":
            wallet.balance += amount
        elif txn_type == "debit":
            wallet.balance -= amount

        ref_receipt = f"TXN-{uuid.uuid4().hex[:12].upper()}"
        txn_log = WalletTransaction(
            wallet_id=wallet_id,
            amount=amount,
            transaction_type=txn_type,
            description=desc,
            reference_id=ref_receipt,
            status="completed"
        )
        db.add(txn_log)
        db.commit()
        db.refresh(txn_log)
        return txn_log

    def get_user_transactions(self, db: Session, wallet_id: uuid.UUID) -> List[WalletTransaction]:
        return db.query(WalletTransaction).filter(WalletTransaction.wallet_id == wallet_id).order_by(WalletTransaction.created_at.desc()).all()

    def get_active_passes(self, db: Session, user_id: uuid.UUID) -> List[TransitPass]:
        now = datetime.utcnow()
        return db.query(TransitPass).filter(
            TransitPass.user_id == user_id,
            TransitPass.expires_at > now,
            TransitPass.is_active == True
        ).all()

    def purchase_pass(self, db: Session, user_id: uuid.UUID, pass_item: TransitPass) -> TransitPass:
        db.add(pass_item)
        db.commit()
        db.refresh(pass_item)
        return pass_item

# Expose singleton
wallet_repo = WalletRepository()
