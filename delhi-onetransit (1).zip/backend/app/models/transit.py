# backend/app/models/transit.py
from sqlalchemy import Column, String, Integer, ForeignKey, Float, Boolean, Time, UniqueConstraint
from sqlalchemy.orm import relationship
from backend.app.models.base import Base, TimestampMixin

class TransportMode(Base):
    """
    Standard enumeration mapping Delhi transport options (Metro, Bus, Suburban Train, E-Rickshaw, Walk).
    """
    __tablename__ = "transport_modes"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False, unique=True)  # e.g., "Delhi Metro"
    code = Column(String(20), nullable=False, unique=True)  # "METRO", "BUS", "TRAIN", "RICKSHAW", "WALK"
    co2_saved_g_per_km = Column(Float, default=0.0, nullable=False) # Comparison vs single passenger petrol cars on Delhi roads


class TransitAgency(Base):
    """
    Agencies serving physical routes.
    """
    __tablename__ = "transit_agencies"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, unique=True)  # "DMRC", "DTC", "Northern Railways", "E-Rickshaw Association"
    contact_number = Column(String(20), nullable=True)
    website = Column(String(150), nullable=True)


# =====================================================================
# DELHI METRO COMPONENT (DMRC)
# =====================================================================

class MetroLine(Base):
    """
    DMRC lines (Blue Line, Yellow Line, etc.) and color-coding tags.
    """
    __tablename__ = "metro_lines"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), unique=True, nullable=False)  # "Yellow Line", "Blue Line"
    color_hex = Column(String(7), nullable=False)  # "#FFDD00", "#0000FF"
    is_active = Column(Boolean, default=True, nullable=False)

    stations = relationship("MetroLineStation", back_populates="line", cascade="all, delete-orphan")


class MetroStation(Base):
    """
    Physical Metro stations with geopoints.
    """
    __tablename__ = "metro_stations"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False, index=True)  # "Rajiv Chowk"
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    is_interchange = Column(Boolean, default=False, nullable=False)
    has_elevator = Column(Boolean, default=True, nullable=False)
    has_parking = Column(Boolean, default=False, nullable=False)

    lines = relationship("MetroLineStation", back_populates="station", cascade="all, delete-orphan")


class MetroLineStation(Base):
    """
    Junction linking stations to lines in an ordered sequence to enable path-finding.
    """
    __tablename__ = "metro_line_stations"

    id = Column(Integer, primary_key=True)
    line_id = Column(Integer, ForeignKey("metro_lines.id", ondelete="CASCADE"), nullable=False)
    station_id = Column(Integer, ForeignKey("metro_stations.id", ondelete="CASCADE"), nullable=False)
    sequence_order = Column(Integer, nullable=False)

    line = relationship("MetroLine", back_populates="stations")
    station = relationship("MetroStation", back_populates="lines")

    __table_args__ = (
        UniqueConstraint("line_id", "station_id", name="uq_line_station"),
    )


class MetroFare(Base):
    """
    Precalculated / zone-calculated fare slabs for Metro stations journeys.
    """
    __tablename__ = "metro_fares"

    id = Column(Integer, primary_key=True)
    source_station_name = Column(String(100), nullable=False)
    dest_station_name = Column(String(100), nullable=False)
    original_fare = Column(Float, nullable=False)
    smart_card_fare = Column(Float, nullable=False)


# =====================================================================
# DTC BUS COMPONENT (DTC)
# =====================================================================

class BusRoute(Base):
    """
    Delhi Transport Corporation route markers (e.g. 502, 419, GL23).
    """
    __tablename__ = "bus_routes"

    id = Column(Integer, primary_key=True, index=True)
    route_code = Column(String(20), unique=True, nullable=False, index=True)  # "502"
    source_stop = Column(String(100), nullable=False)
    destination_stop = Column(String(100), nullable=False)
    is_ac = Column(Boolean, default=False, nullable=False)  # True = AC Bus, False = Ordinary Green Bus
    is_active = Column(Boolean, default=True, nullable=False)

    stops = relationship("BusRouteStop", back_populates="route", cascade="all, delete-orphan")


class BusStop(Base):
    """
    Physical stops on paths using regional descriptors.
    """
    __tablename__ = "bus_stops"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False, index=True)  # "Vasant Kunj Sector C"
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)

    routes = relationship("BusRouteStop", back_populates="stop", cascade="all, delete-orphan")


class BusRouteStop(Base):
    """
    Correlates buses and stops sequentially.
    """
    __tablename__ = "bus_route_stops"

    id = Column(Integer, primary_key=True)
    route_id = Column(Integer, ForeignKey("bus_routes.id", ondelete="CASCADE"), nullable=False)
    stop_id = Column(Integer, ForeignKey("bus_stops.id", ondelete="CASCADE"), nullable=False)
    sequence_order = Column(Integer, nullable=False)

    route = relationship("BusRoute", back_populates="stops")
    stop = relationship("BusStop", back_populates="routes")

    __table_args__ = (
        UniqueConstraint("route_id", "stop_id", name="uq_route_stop"),
    )


class BusTiming(Base):
    """
    Schedules for DTC dispatch times.
    """
    __tablename__ = "bus_timings"

    id = Column(Integer, primary_key=True)
    route_id = Column(Integer, ForeignKey("bus_routes.id", ondelete="CASCADE"), nullable=False)
    scheduled_departure = Column(Time, nullable=False)
    frequency_minutes = Column(Integer, default=15, nullable=False)


# =====================================================================
# SUBURBAN EMU RAILWAY COMPONENT
# =====================================================================

class TrainStation(Base):
    """
    EMU Suburban rail stops in outer regions of NCR.
    """
    __tablename__ = "train_stations"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False, index=True)  # "Hazrat Nizamuddin"
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)


class TrainRoute(Base):
    """
    Routes connecting out-of-town railheads.
    """
    __tablename__ = "train_routes"

    id = Column(Integer, primary_key=True, index=True)
    route_name = Column(String(100), unique=True, nullable=False)  # "Delhi-Ghaziabad EMU"
    stations_json = Column(String(512), nullable=False)  # List of ordered stations as JSON list


class TrainFareSlab(Base):
    """
    Distance-slab-based fares for EMU rail trips.
    """
    __tablename__ = "train_fare_slabs"

    id = Column(Integer, primary_key=True)
    min_distance_km = Column(Float, nullable=False)
    max_distance_km = Column(Float, nullable=False)
    general_ticket_fare = Column(Float, nullable=False)
    monthly_pass_fare = Column(Float, nullable=False)


# =====================================================================
# FEEDER SERVICE COMPONENT (E-RICKSHAW)
# =====================================================================

class ERickshawZone(Base):
    """
    Zones mapping legal coverage grids (usually around major hubs).
    """
    __tablename__ = "erickshaw_zones"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)  # "GTB Nagar Hub"
    central_latitude = Column(Float, nullable=False)
    central_longitude = Column(Float, nullable=False)
    radius_meters = Column(Float, default=1500.0, nullable=False)
    base_fare = Column(Float, default=10.0, nullable=False)
    per_km_fare = Column(Float, default=15.0, nullable=False)


class ERickshawOperator(Base, TimestampMixin):
    """
    Operators registered with regional authorities for rides safety audit.
    """
    __tablename__ = "erickshaw_operators"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    license_number = Column(String(50), unique=True, nullable=False)
    vehicle_registration = Column(String(30), unique=True, nullable=False)
    zone_id = Column(Integer, ForeignKey("erickshaw_zones.id", ondelete="SET NULL"), nullable=True)
    phone_number = Column(String(20), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
