# backend/app/models/history.py
import uuid
from sqlalchemy import Column, String, ForeignKey, Float, Integer, DateTime
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from backend.app.models.base import Base, TimestampMixin

class TravelTrip(Base, TimestampMixin):
    """
    Consolidated record of a unified commuter multi-modal journey.
    """
    __tablename__ = "travel_trips"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    source_address = Column(String(255), nullable=False)
    destination_address = Column(String(255), nullable=False)
    total_fare = Column(Float, default=0.0, nullable=False)
    total_distance_km = Column(Float, default=0.0, nullable=False)
    total_duration_minutes = Column(Float, default=0.0, nullable=False)
    co2_saved_g = Column(Float, default=0.0, nullable=False) # Total carbon footprint reduction (vs diesel cars)
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=False)

    user = relationship("User", back_populates="trips")
    legs = relationship("TravelTripLeg", back_populates="trip", cascade="all, delete-orphan")


class TravelTripLeg(Base):
    """
    Specific modal legs making up a single multi-modal journey.
    """
    __tablename__ = "travel_trip_legs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    trip_id = Column(UUID(as_uuid=True), ForeignKey("travel_trips.id", ondelete="CASCADE"), nullable=False, index=True)
    transport_code = Column(String(20), nullable=False) # e.g., "METRO", "BUS", "RICKSHAW", "WALK"
    source_name = Column(String(150), nullable=False) # Station, stop, or point name
    destination_name = Column(String(150), nullable=False)
    fare = Column(Float, default=0.0, nullable=False)
    distance_km = Column(Float, default=0.0, nullable=False)
    duration_minutes = Column(Float, default=0.0, nullable=False)
    sequence_order = Column(Integer, nullable=False) # Leg order (e.g. 1st walk, 2nd Metro...)

    trip = relationship("TravelTrip", back_populates="legs")
