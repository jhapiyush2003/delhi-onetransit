# backend/app/models/wallet.py
import uuid
from sqlalchemy import Column, String, ForeignKey, Float, Integer, DateTime, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from backend.app.models.base import Base, TimestampMixin

class Wallet(Base, TimestampMixin):
    """
    User smart wallet containing stored energy balances for seamless ticketing.
    """
    __tablename__ = "wallets"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    balance = Column(Float, default=150.0, nullable=False)  # default signup balance freebie for recruiters
    security_pin_hash = Column(String(255), nullable=True) # Optional secure payment confirmation
    status = Column(String(50), default="active", nullable=False) # active, suspended, locked

    user = relationship("User", back_populates="wallet")
    transactions = relationship("WalletTransaction", back_populates="wallet", cascade="all, delete-orphan")


class WalletTransaction(Base, TimestampMixin):
    """
    Full double-entry transaction history registering debits, credits, and refunds.
    """
    __tablename__ = "wallet_transactions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    wallet_id = Column(UUID(as_uuid=True), ForeignKey("wallets.id", ondelete="CASCADE"), nullable=False, index=True)
    amount = Column(Float, nullable=False)
    transaction_type = Column(String(50), nullable=False)  # "credit", "debit", "refund"
    reference_id = Column(String(100), unique=True, nullable=True) # Link to digital receipts
    description = Column(String(255), nullable=False)  # e.g., "Delhi Metro - Rajiv Chowk to Kashmere Gate"
    status = Column(String(50), default="completed", nullable=False) # completed, pending, failed

    wallet = relationship("Wallet", back_populates="transactions")


class TransitPass(Base, TimestampMixin):
    """
    Subscribed transit passes supporting unlimited rides on selected criteria.
    """
    __tablename__ = "transit_passes"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    pass_type = Column(String(100), nullable=False) # "DTC Monthly Ordinary Bus", "Delhi Metro Tourist Pass", "EMU Pass"
    transport_mode = Column(String(50), nullable=False) # "METRO", "BUS", "TRAIN"
    price = Column(Float, nullable=False)
    starts_at = Column(DateTime, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)

    user = relationship("User", back_populates="passes")
