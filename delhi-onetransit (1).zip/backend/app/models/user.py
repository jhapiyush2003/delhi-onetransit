# backend/app/models/user.py
import uuid
from sqlalchemy import Column, String, ForeignKey, Integer, Boolean, DateTime
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from backend.app.models.base import Base, TimestampMixin

class User(Base, TimestampMixin):
    """
    Core User table representing verified transit accounts.
    """
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    full_name = Column(String(150), nullable=False)
    role = Column(String(50), default="User", nullable=False)  # User, Admin
    status = Column(String(50), default="active", nullable=False)  # active, suspended, closed
    is_verified = Column(Boolean, default=False, nullable=False)

    # Relationships
    password = relationship("UserPassword", back_populates="user", uselist=False, cascade="all, delete-orphan")
    profile = relationship("UserProfile", back_populates="user", uselist=False, cascade="all, delete-orphan")
    refresh_tokens = relationship("UserRefreshToken", back_populates="user", cascade="all, delete-orphan")
    login_logs = relationship("UserLoginLog", back_populates="user", cascade="all, delete-orphan")
    wallet = relationship("Wallet", back_populates="user", uselist=False, cascade="all, delete-orphan")
    passes = relationship("TransitPass", back_populates="user", cascade="all, delete-orphan")
    trips = relationship("TravelTrip", back_populates="user", cascade="all, delete-orphan")


class UserPassword(Base, TimestampMixin):
    """
    Hashed credentials store with tracking logs to prevent brute force entries.
    """
    __tablename__ = "user_passwords"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    failed_attempts = Column(Integer, default=0, nullable=False)
    locked_until = Column(DateTime, nullable=True)

    # Relationship
    user = relationship("User", back_populates="password")


class UserRefreshToken(Base, TimestampMixin):
    """
    Tracks active client tokens supporting secure session persistence.
    """
    __tablename__ = "user_refresh_tokens"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    token = Column(String(512), unique=True, nullable=False, index=True)
    expires_at = Column(DateTime, nullable=False)
    is_revoked = Column(Boolean, default=False, nullable=False)
    device_info = Column(String(255), nullable=True)

    # Relationship
    user = relationship("User", back_populates="refresh_tokens")


class UserProfile(Base, TimestampMixin):
    """
    Extended user profile for preferred lines and commuting coordinates.
    """
    __tablename__ = "user_profiles"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    phone_number = Column(String(20), nullable=True)
    preferred_language = Column(String(10), default="en", nullable=False)
    home_latitude = Column(String(50), nullable=True)
    home_longitude = Column(String(50), nullable=True)
    work_latitude = Column(String(50), nullable=True)
    work_longitude = Column(String(50), nullable=True)

    # Relationship
    user = relationship("User", back_populates="profile")


class UserLoginLog(Base):
    """
    Security audit trails tracking login origins.
    """
    __tablename__ = "user_login_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(String(255), nullable=True)
    is_success = Column(Boolean, default=True, nullable=False)
    timestamp = Column(DateTime, default=DateTime, nullable=False)

    # Relationship
    user = relationship("User", back_populates="login_logs")
