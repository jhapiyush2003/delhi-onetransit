# backend/app/models/base.py
import datetime
from sqlalchemy import Column, DateTime
from sqlalchemy.orm import declarative_base, declared_attr

# Create declarative base
Base = declarative_base()

class TimestampMixin:
    """
    Mixin that appends audit timestamps to tracking tables automatically.
    """
    @declared_attr
    def created_at(cls):
        return Column(DateTime, default=datetime.datetime.utcnow, nullable=False)

    @declared_attr
    def updated_at(cls):
        return Column(
            DateTime,
            default=datetime.datetime.utcnow,
            onupdate=datetime.datetime.utcnow,
            nullable=False
        )
